﻿namespace imageEdit
{
    partial class ImageEditor
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.열기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.저장ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.끝내기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.이미지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.이미지일부확대및축소ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.비트맵복사ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.비트맵확대축소ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.그레이이미지로변환ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.폰트로마크넣기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.바이너리저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.바이너리열기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem,
            this.이미지ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(723, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.열기ToolStripMenuItem,
            this.저장ToolStripMenuItem1,
            this.바이너리열기ToolStripMenuItem,
            this.바이너리저장ToolStripMenuItem,
            this.끝내기ToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.mENUToolStripMenuItem.Text = "파일";
            // 
            // 열기ToolStripMenuItem
            // 
            this.열기ToolStripMenuItem.Name = "열기ToolStripMenuItem";
            this.열기ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.열기ToolStripMenuItem.Text = "열기";
            this.열기ToolStripMenuItem.Click += new System.EventHandler(this.열기ToolStripMenuItem_Click);
            // 
            // 저장ToolStripMenuItem1
            // 
            this.저장ToolStripMenuItem1.Name = "저장ToolStripMenuItem1";
            this.저장ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.저장ToolStripMenuItem1.Text = "저장";
            this.저장ToolStripMenuItem1.Click += new System.EventHandler(this.저장ToolStripMenuItem1_Click);
            // 
            // 끝내기ToolStripMenuItem
            // 
            this.끝내기ToolStripMenuItem.Name = "끝내기ToolStripMenuItem";
            this.끝내기ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.끝내기ToolStripMenuItem.Text = "끝내기";
            this.끝내기ToolStripMenuItem.Click += new System.EventHandler(this.끝내기ToolStripMenuItem_Click);
            // 
            // 이미지ToolStripMenuItem
            // 
            this.이미지ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.이미지일부확대및축소ToolStripMenuItem,
            this.비트맵복사ToolStripMenuItem1,
            this.비트맵확대축소ToolStripMenuItem1,
            this.그레이이미지로변환ToolStripMenuItem,
            this.폰트로마크넣기ToolStripMenuItem});
            this.이미지ToolStripMenuItem.Name = "이미지ToolStripMenuItem";
            this.이미지ToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.이미지ToolStripMenuItem.Text = "이미지";
            // 
            // 이미지일부확대및축소ToolStripMenuItem
            // 
            this.이미지일부확대및축소ToolStripMenuItem.Name = "이미지일부확대및축소ToolStripMenuItem";
            this.이미지일부확대및축소ToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.이미지일부확대및축소ToolStripMenuItem.Text = "이미지 일부 확대 및 축소";
            this.이미지일부확대및축소ToolStripMenuItem.Click += new System.EventHandler(this.이미지일부확대및축소ToolStripMenuItem_Click);
            // 
            // 비트맵복사ToolStripMenuItem1
            // 
            this.비트맵복사ToolStripMenuItem1.Name = "비트맵복사ToolStripMenuItem1";
            this.비트맵복사ToolStripMenuItem1.Size = new System.Drawing.Size(212, 22);
            this.비트맵복사ToolStripMenuItem1.Text = "비트맵 복사";
            this.비트맵복사ToolStripMenuItem1.Click += new System.EventHandler(this.비트맵복사ToolStripMenuItem1_Click);
            // 
            // 비트맵확대축소ToolStripMenuItem1
            // 
            this.비트맵확대축소ToolStripMenuItem1.Name = "비트맵확대축소ToolStripMenuItem1";
            this.비트맵확대축소ToolStripMenuItem1.Size = new System.Drawing.Size(212, 22);
            this.비트맵확대축소ToolStripMenuItem1.Text = "비트맵 확대 축소";
            this.비트맵확대축소ToolStripMenuItem1.Click += new System.EventHandler(this.비트맵확대축소ToolStripMenuItem1_Click);
            // 
            // 그레이이미지로변환ToolStripMenuItem
            // 
            this.그레이이미지로변환ToolStripMenuItem.Name = "그레이이미지로변환ToolStripMenuItem";
            this.그레이이미지로변환ToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.그레이이미지로변환ToolStripMenuItem.Text = "그레이 이미지로 변환";
            this.그레이이미지로변환ToolStripMenuItem.Click += new System.EventHandler(this.그레이이미지로변환ToolStripMenuItem_Click);
            // 
            // 폰트로마크넣기ToolStripMenuItem
            // 
            this.폰트로마크넣기ToolStripMenuItem.Name = "폰트로마크넣기ToolStripMenuItem";
            this.폰트로마크넣기ToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.폰트로마크넣기ToolStripMenuItem.Text = "폰트로 마크넣기";
            this.폰트로마크넣기ToolStripMenuItem.Click += new System.EventHandler(this.폰트로마크넣기ToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(723, 399);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // 바이너리저장ToolStripMenuItem
            // 
            this.바이너리저장ToolStripMenuItem.Name = "바이너리저장ToolStripMenuItem";
            this.바이너리저장ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.바이너리저장ToolStripMenuItem.Text = "바이너리 저장";
            this.바이너리저장ToolStripMenuItem.Click += new System.EventHandler(this.바이너리저장ToolStripMenuItem_Click);
            // 
            // 바이너리열기ToolStripMenuItem
            // 
            this.바이너리열기ToolStripMenuItem.Name = "바이너리열기ToolStripMenuItem";
            this.바이너리열기ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.바이너리열기ToolStripMenuItem.Text = "바이너리 열기";
            this.바이너리열기ToolStripMenuItem.Click += new System.EventHandler(this.바이너리열기ToolStripMenuItem_Click);
            // 
            // ImageEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 423);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "ImageEditor";
            this.Text = "이미지에디터";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 열기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 저장ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 끝내기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 이미지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 이미지일부확대및축소ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 비트맵복사ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 비트맵확대축소ToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem 그레이이미지로변환ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 폰트로마크넣기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 바이너리저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 바이너리열기ToolStripMenuItem;
    }
}

