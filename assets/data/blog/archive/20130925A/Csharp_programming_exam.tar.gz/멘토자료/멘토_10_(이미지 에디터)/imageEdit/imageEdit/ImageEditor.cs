﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;

namespace imageEdit
{
    public partial class ImageEditor : Form
    {
        private Graphics myGraphics;    // Graphics 객체 [memory 저장]
        private Bitmap ImageBmp;        // Bitmap 객체

        public ImageEditor()
        {
            InitializeComponent();
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDlg = new OpenFileDialog();

            openFileDlg.InitialDirectory = "c:\\";
            openFileDlg.Filter = "bmp files (*bmp)|*.bmp|All files (*.*)|*.*";
            openFileDlg.FilterIndex = 2;
            openFileDlg.RestoreDirectory = true;

            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                ImageBmp = new Bitmap(openFileDlg.FileName);
                myGraphics = Graphics.FromImage(ImageBmp);
                pictureBox1.Image = ImageBmp;
                               
            }
        }        

        private void 저장ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();

            saveFileDlg.InitialDirectory = "c:\\";
            saveFileDlg.Filter = "jpg files (*jpg)|*.jpg|All files (*.*)|*.*";
            saveFileDlg.FilterIndex = 2;
            saveFileDlg.RestoreDirectory = true;

            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                myGraphics.Save();
                ImageBmp.Save(saveFileDlg.FileName, ImageFormat.Jpeg);               
            }
        }
       
        private void 이미지일부확대및축소ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rectangle sourceRectangle = new Rectangle(80, 70, 80, 45);
            Rectangle destRectangle1 = new Rectangle(200, 10, 20, 16);
            Rectangle destRectangle2 = new Rectangle(200, 40, 200, 160);

            Bitmap secondBitmap = new Bitmap(ImageBmp);

            myGraphics.DrawImage(secondBitmap, 0, 0);
            myGraphics.DrawImage(secondBitmap, destRectangle1, sourceRectangle, GraphicsUnit.Pixel);
            myGraphics.DrawImage(secondBitmap, destRectangle2, sourceRectangle, GraphicsUnit.Pixel);

            pictureBox1.Image = ImageBmp;
        }

        private void 비트맵복사ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Rectangle sourceRectangle = new Rectangle(0, 0, ImageBmp.Width, ImageBmp.Height / 2);
            Bitmap secondBitmap = ImageBmp.Clone(sourceRectangle, PixelFormat.DontCare);

            myGraphics.DrawImage(ImageBmp, 10, 10);
            myGraphics.DrawImage(secondBitmap, 150, 10);

            secondBitmap.Dispose();

            pictureBox1.Image = ImageBmp;
        }

        private void 비트맵확대축소ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Rectangle expansionRectangle = new Rectangle(135, 10, (int)(ImageBmp.Width * 1.5), (int)(ImageBmp.Height * 1.5));
            Rectangle compressionRectangle = new Rectangle(300, 10, (int)(ImageBmp.Width / 2.5), (int)(ImageBmp.Height / 2.5));

            Bitmap secondBitmap = new Bitmap(ImageBmp);

            myGraphics.DrawImage(secondBitmap, 10, 10);
            myGraphics.DrawImage(secondBitmap, expansionRectangle);
            myGraphics.DrawImage(secondBitmap, compressionRectangle);

            pictureBox1.Image = ImageBmp;
        }

        private void 그레이이미지로변환ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int mean;
            Color px;
            Color[] grayColors = new Color[256];
            for (int i = 0; i < 256; i++)
            {
                grayColors[i] = Color.FromArgb(i, i, i);
            }

            for (int y = 0; y < ImageBmp.Height; y++)
            {
                for (int x = 0; x < ImageBmp.Width; x++)
                {
                    px = ImageBmp.GetPixel(x, y);
                    mean = (int)Math.Sqrt((px.R * px.R + px.G * px.G + px.B * px.B) / 3);
                    ImageBmp.SetPixel(x, y, grayColors[mean]);
                }
            }

            myGraphics.DrawImage(ImageBmp, 0, 0);
            pictureBox1.Image = ImageBmp;
        }

        private void 폰트로마크넣기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "장영완";
            Font font = new Font("Gulim", 20);

            SolidBrush brush = new SolidBrush(Color.White);
            PointF point = new PointF(150.0F, 150.0F);

            myGraphics.DrawString(text, font, brush, point);
            font.Dispose();
            brush.Dispose();

            pictureBox1.Image = ImageBmp;
        }

        private void 끝내기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 바이너리저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDlg = new SaveFileDialog();

            saveFileDlg.InitialDirectory = "c:\\";
            saveFileDlg.Filter = "dat files (*dat)|*.dat|All files (*.*)|*.*";
            saveFileDlg.FilterIndex = 2;
            saveFileDlg.RestoreDirectory = true;

            if (saveFileDlg.ShowDialog() == DialogResult.OK)
            {
                MemoryStream ms = new MemoryStream();
                ImageBmp.Save(ms, ImageFormat.Jpeg);
                byte[] bitmapData = ms.ToArray();

                FileStream fs = new FileStream(saveFileDlg.FileName, FileMode.CreateNew);
                BinaryWriter w = new BinaryWriter(fs);

                w.Write(bitmapData);

                w.Close();
                fs.Close();
                ms.Flush();
            }
        }

        private void 바이너리열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDlg = new OpenFileDialog();

            openFileDlg.InitialDirectory = "c:\\";
            openFileDlg.Filter = "data files (*dat)|*.dat|All files (*.*)|*.*";
            openFileDlg.FilterIndex = 2;
            openFileDlg.RestoreDirectory = true;

            if (openFileDlg.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(openFileDlg.FileName, FileMode.Open);
                BinaryReader r = new BinaryReader(fs);                               

                byte[] bitmapData = r.ReadBytes((int)fs.Length);

                MemoryStream ms = new MemoryStream(bitmapData);
                ImageBmp = (Bitmap)Bitmap.FromStream(ms);
                pictureBox1.Image = ImageBmp;

                r.Close();
                fs.Close();
            }
        }
    }
}
