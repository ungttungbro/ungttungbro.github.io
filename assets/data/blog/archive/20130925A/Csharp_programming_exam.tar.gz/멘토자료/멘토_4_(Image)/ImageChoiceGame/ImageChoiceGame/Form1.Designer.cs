﻿namespace ImageChoiceGame
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panFloor = new System.Windows.Forms.PictureBox();
            this.GameLevel = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.GameStart = new System.Windows.Forms.Button();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.QUIT = new System.Windows.Forms.Button();
            this.timerAni = new System.Windows.Forms.Timer(this.components);
            this.timerCnt = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.panFloor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameLevel)).BeginInit();
            this.SuspendLayout();
            // 
            // panFloor
            // 
            this.panFloor.Location = new System.Drawing.Point(13, 13);
            this.panFloor.Name = "panFloor";
            this.panFloor.Size = new System.Drawing.Size(283, 381);
            this.panFloor.TabIndex = 0;
            this.panFloor.TabStop = false;
            // 
            // GameLevel
            // 
            this.GameLevel.Location = new System.Drawing.Point(387, 13);
            this.GameLevel.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.GameLevel.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.GameLevel.Name = "GameLevel";
            this.GameLevel.Size = new System.Drawing.Size(51, 21);
            this.GameLevel.TabIndex = 1;
            this.GameLevel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(315, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "게임레빌 :";
            // 
            // GameStart
            // 
            this.GameStart.Location = new System.Drawing.Point(317, 40);
            this.GameStart.Name = "GameStart";
            this.GameStart.Size = new System.Drawing.Size(121, 23);
            this.GameStart.TabIndex = 3;
            this.GameStart.Text = "게임시작";
            this.GameStart.UseVisualStyleBackColor = true;
            this.GameStart.Click += new System.EventHandler(this.GameStart_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTime.Location = new System.Drawing.Point(313, 108);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(52, 21);
            this.lblTime.TabIndex = 7;
            this.lblTime.Text = "시간 :";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore.Location = new System.Drawing.Point(313, 77);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(84, 21);
            this.lblScore.TabIndex = 6;
            this.lblScore.Text = "틀린횟수 :";
            // 
            // QUIT
            // 
            this.QUIT.Location = new System.Drawing.Point(317, 370);
            this.QUIT.Name = "QUIT";
            this.QUIT.Size = new System.Drawing.Size(121, 23);
            this.QUIT.TabIndex = 8;
            this.QUIT.Text = "종료";
            this.QUIT.UseVisualStyleBackColor = true;
            this.QUIT.Click += new System.EventHandler(this.QUIT_Click);
            // 
            // timerAni
            // 
            this.timerAni.Interval = 500;
            this.timerAni.Tick += new System.EventHandler(this.timerAni_Tick);
            // 
            // timerCnt
            // 
            this.timerCnt.Tick += new System.EventHandler(this.timerCnt_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 409);
            this.Controls.Add(this.QUIT);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.GameStart);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GameLevel);
            this.Controls.Add(this.panFloor);
            this.Name = "MainForm";
            this.Text = "이미지 순서 맞추기 게임";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panFloor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameLevel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox panFloor;
        private System.Windows.Forms.NumericUpDown GameLevel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button GameStart;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Button QUIT;
        private System.Windows.Forms.Timer timerAni;
        private System.Windows.Forms.Timer timerCnt;
    }
}

