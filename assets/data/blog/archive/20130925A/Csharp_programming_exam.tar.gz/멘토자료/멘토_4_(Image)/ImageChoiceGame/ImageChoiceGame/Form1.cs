﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ImageChoiceGame
{
    public partial class MainForm : Form
    {
        // NoImage
        string NoImage = "nophoto_60x80.gif";

        // 이미지 목록
        PictureBox[] images = new PictureBox[16];

        // 게임의 답을 저장하는 배열변수
        int[] results = new int[16];

        // 게임레벨
        int nGameLevel = 1;

        // 이미지 개수
        int nAniPos = 0;

        // 타이머
        int nTimer = 0;

        // 게임중인지 저장
        bool bGameIng = false;

        int nUserPos = 0;

        int nFailCnt = 1;

        //-----------------------------------------------------------



                        
        public MainForm()
        {
            InitializeComponent();
        }

        private void initializeGame()
        {
            Random R = new Random();
            bool bCheck = false;

            timerCnt.Stop();

            // 이미지를 뒤집는다.
            for (int i = 0; i < images.Length; i++)
            {
                Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + NoImage);
                images[i].Image = (Image)ResourceImage;
                images[i].Tag = i.ToString();
            }

            // 레벨에 따라 뒤집는 갯수를 정하고 배열에 순서대로 저장한다.
            nGameLevel = (int)GameLevel.Value;

            for (int i = 0; i < nGameLevel; i++, bCheck = false)
            {
                int nRandom = R.Next(0, results.Length);

                for (int j = 0; j < i; j++)
                {
                    // 동일한 번호가 중복되지 않게하기 위해...
                    if (results[j] == nRandom)
                    {
                        i--;
                        bCheck = true;
                        break;
                    }
                }

                if (bCheck) continue;

                results[i] = nRandom;
            }

            // 카드 뒤집기 시작.
            nAniPos = 0;
            timerAni.Interval = 500;
            timerAni.Start();
        }


        private void timerCnt_Tick(object sender, EventArgs e)
        {
            nTimer += 1;

            int millTime = nTimer % 100;
            int secTime = (nTimer % (60 * 100)) / 100;
            int minTime = (nTimer % (60 * 60 * 100)) / (60 * 100);
            int hourTime = nTimer / (60 * 60 * 100);
            lblTime.Text = string.Format("시간 : {0}:{1}:{2}.{3}", hourTime, minTime, secTime, millTime);
        }


        // 카드 뒤집기 타이머.
        // 정답 저장한 순서대로 한장씩 뒤집고 전부 뒤집고나면 1초간의 딜레이를 더 주고 카드를 전부 뒤집고 게임타이머를 시작한다.
        private void timerAni_Tick(object sender, EventArgs e)
        {
            if (nAniPos > nGameLevel - 1)
            {
                lblScore.Text = "틀린횟수 : ";
                lblTime.Text = "시간 : ";

                AllClose();

                timerAni.Stop();
                timerCnt.Start();
            }
            else
            {   
                int width = images[results[nAniPos]].Width;
                int height = images[results[nAniPos]].Height;
                int x = images[results[nAniPos]].Left;
                int y = images[results[nAniPos]].Top;

                Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + results[nAniPos].ToString() + ".jpg");
                images[results[nAniPos]].Image = (Image)ResourceImage;
                
                nAniPos++;
            }

            if (nAniPos > nGameLevel - 1)
            {
                timerAni.Interval = 1500;
            }
        }

        private void QUIT_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FlipImage_Click(object sender, EventArgs e)
        {
            if (!bGameIng)
            {
                return;
            }

            PictureBox PB = (PictureBox)sender;

            int nNumber = Int32.Parse(PB.Tag.ToString());

            if (nNumber == results[nUserPos])
			{
                Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + (results[nUserPos]).ToString() + ".jpg");
                images[nNumber].Image = (Image)ResourceImage;

                nUserPos++;

                // 성공처리
                if (nUserPos > nGameLevel - 1)
                {
                    bGameIng = false;
                    timerCnt.Stop();
                    MessageBox.Show(string.Format("{0}초, {1}회 만에 성공하였습니다.", (float)nTimer / 100, nFailCnt));
                }
            }
            else
            {
                 Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + NoImage);
                 images[nNumber].Image = (Image)ResourceImage;
                    
                 nFailCnt++;
                 lblScore.Text = "틀린횟수 : " + nFailCnt;            
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            initializeImageBox();
        }


        // PitureBox 초기화
        private void initializeImageBox()
        {
            // 이미지컨트롤 위치를 고정시킨다.
            // 기존 예제와 다른점은 사용자 클래스를 이용한다는 것.
            for (int i = 0; i < images.Length; i++)
            {
                images[i] = new PictureBox();

                images[i].Width = 60;
                images[i].Height = 80;
                images[i].Top = ((i / 4) * 2 /* 공백 */  + (i / 4) * images[i].Height) /* 이미지높이 */ + 10;
                images[i].Left = ((i % 4) * 2 /* 공백 */  + (i % 4) * images[i].Width) /* 이미지넓이 */ + 10;

                Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + (i + 1).ToString() + ".jpg");
                images[i].Image = (Image)ResourceImage;
                images[i].Tag = i.ToString();
               
                images[i].Click += new EventHandler(FlipImage_Click);
                panFloor.Controls.Add(images[i]);
            }
        }

        private void GameStart_Click(object sender, EventArgs e)
        {
            bGameIng = true;

            initializeGame();
        }
       

        private void AllClose()
        {
            Bitmap ResourceImage = new Bitmap("..\\..\\Resources\\" + NoImage);

            for (int i = 0; i < images.Length; i++)
            {
                PictureBox PB = images[i];
                PB.Image = (Image)ResourceImage;
                PB.Tag = i.ToString();
            }
        }
    }
}
