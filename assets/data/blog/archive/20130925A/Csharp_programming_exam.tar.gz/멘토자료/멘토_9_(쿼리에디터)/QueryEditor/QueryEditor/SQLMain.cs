﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace QueryEditor
{
    public partial class SQLMain : Form
    {
        public SQLMain()
        {
            InitializeComponent();
        }

        private void 새쿼리창생성ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SQLChild newMDIChild = new SQLChild();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }
       
        private void 쿼리불러오기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SQLChild newMDIChild = new SQLChild();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();

            if (newMDIChild != null)
            {
                OpenFileDialog of = new OpenFileDialog();
                of.Filter = "rtf 문서|*.rtf|모든문서|*.*";
                of.InitialDirectory = Environment.SpecialFolder.Personal.ToString();
                of.FileName = "";

                if (of.ShowDialog() == DialogResult.OK)
                {
                    RichTextBox rtb = (RichTextBox)newMDIChild.ActiveControl;
                    if (rtb != null)
                    {
                        rtb.LoadFile(of.FileName, RichTextBoxStreamType.PlainText);
                    }
                }
            }
        }

        private void 쿼리저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = this.ActiveMdiChild;

            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "rtf 문서|*.rtf";
            sf.DefaultExt = "*.rtf";
            sf.InitialDirectory = Environment.SpecialFolder.Personal.ToString();
            sf.FileName = "";

            if (sf.ShowDialog() == DialogResult.OK)
            {
                RichTextBox rtb = (RichTextBox)form.ActiveControl;

                if (rtb != null)
                {
                    rtb.SaveFile(sf.FileName, RichTextBoxStreamType.PlainText);
                }
            }           
        }

        private void SQLMain_Load(object sender, EventArgs e)
        {

        }

        private void tsbSave_Click(object sender, EventArgs e)
        {
            Form form = this.ActiveMdiChild;

            RichTextBox rtb = (RichTextBox)form.ActiveControl;
            string Query = rtb.SelectedText;


            QueryResult newMDIChild = new QueryResult();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();

            try
            {             
                OleDbConnection Conn = new OleDbConnection();
                Conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
                                    + @"E:\C# 프로그래밍\QueryEditor\QueryEditor\bin\Debug\bin\Database.mdb" + ";Persist Security Info=False;";

                Conn.Open();
                               
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(Query, Conn);
                DataSet ds = new DataSet();               

                dataAdapter.Fill(ds, "Students");
            
                DataGridView DGV = (DataGridView)newMDIChild.ActiveControl;
                Conn.Close();

                DGV.DataSource = ds;
                DGV.DataMember = "Students";

                DGV.AutoGenerateColumns = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
