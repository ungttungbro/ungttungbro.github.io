﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QueryEditor
{
    public partial class SQLChild : Form
    {
        public SQLChild()
        {
            InitializeComponent();
        }

        private void SQLChild_Load(object sender, EventArgs e)
        {
            richQueryBox.Focus();
            richQueryBox.Select();
            richQueryBox.Select(0, 0);
            
        }
    }
}
