﻿namespace QueryEditor
{
    partial class SQLChild
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richQueryBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // richQueryBox
            // 
            this.richQueryBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richQueryBox.Location = new System.Drawing.Point(0, 0);
            this.richQueryBox.Name = "richQueryBox";
            this.richQueryBox.Size = new System.Drawing.Size(574, 515);
            this.richQueryBox.TabIndex = 1;
            this.richQueryBox.Text = "";
            // 
            // SQLChild
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 515);
            this.Controls.Add(this.richQueryBox);
            this.Name = "SQLChild";
            this.Text = "SQL 편집창";
            this.Load += new System.EventHandler(this.SQLChild_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richQueryBox;


    }
}