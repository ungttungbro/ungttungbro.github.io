﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 지뢰찾기
{
    public partial class Minesweeper : Form
    {
        public Minesweeper()
        {
            InitializeComponent();
        }

        private void Minesweeper_Load(object sender, EventArgs e)
        {
            this.Width = 25 * 11;
            this.Height = 25 * 12;

            SetButtons();
        }

        private void ButtonHandler(object sender, EventArgs e)
        {
            MessageBox.Show(e.ToString());
        }

        private void SetButtons()
        {            
            for (int i = 0; i < 100; i++)
            {
                Button btn = new Button();
                btn.Size = new Size(25, 25);
                
                int x = 25 * (i % 10); // 버튼의 X좌표
                int y = 25 * (i / 10);// 버튼의 Y좌표

                btn.Location = new Point(x, y);// 버튼의 위치설정

                btn.Tag = i.ToString();

                btn.Click += new EventHandler(this.ButtonHandler);

                this.Controls.Add(btn); // 폼에 추가
            }
        }
    }
}
