﻿namespace AlarmClock
{
    partial class AlarmClock
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlarmClock));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.axMediaPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.cbHour = new System.Windows.Forms.ComboBox();
            this.cbMinute = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btSetAlarm = new System.Windows.Forms.Button();
            this.txtAlarmView = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.axMediaPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // axMediaPlayer
            // 
            this.axMediaPlayer.Enabled = true;
            this.axMediaPlayer.Location = new System.Drawing.Point(228, 12);
            this.axMediaPlayer.Name = "axMediaPlayer";
            this.axMediaPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMediaPlayer.OcxState")));
            this.axMediaPlayer.Size = new System.Drawing.Size(353, 269);
            this.axMediaPlayer.TabIndex = 0;
            // 
            // cbHour
            // 
            this.cbHour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbHour.FormattingEnabled = true;
            this.cbHour.Location = new System.Drawing.Point(52, 229);
            this.cbHour.Name = "cbHour";
            this.cbHour.Size = new System.Drawing.Size(54, 20);
            this.cbHour.TabIndex = 1;
            // 
            // cbMinute
            // 
            this.cbMinute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbMinute.FormattingEnabled = true;
            this.cbMinute.Location = new System.Drawing.Point(136, 229);
            this.cbMinute.Name = "cbMinute";
            this.cbMinute.Size = new System.Drawing.Size(48, 20);
            this.cbMinute.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "알람 :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(107, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "시";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "분";
            // 
            // btSetAlarm
            // 
            this.btSetAlarm.Location = new System.Drawing.Point(12, 260);
            this.btSetAlarm.Name = "btSetAlarm";
            this.btSetAlarm.Size = new System.Drawing.Size(93, 21);
            this.btSetAlarm.TabIndex = 6;
            this.btSetAlarm.Text = "알람설정";
            this.btSetAlarm.UseVisualStyleBackColor = true;
            this.btSetAlarm.Click += new System.EventHandler(this.btSetAlarm_Click);
            // 
            // txtAlarmView
            // 
            this.txtAlarmView.BackColor = System.Drawing.Color.Bisque;
            this.txtAlarmView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAlarmView.Location = new System.Drawing.Point(112, 260);
            this.txtAlarmView.Name = "txtAlarmView";
            this.txtAlarmView.ReadOnly = true;
            this.txtAlarmView.Size = new System.Drawing.Size(92, 21);
            this.txtAlarmView.TabIndex = 7;
            this.txtAlarmView.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // AlarmClock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 293);
            this.Controls.Add(this.txtAlarmView);
            this.Controls.Add(this.btSetAlarm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMinute);
            this.Controls.Add(this.cbHour);
            this.Controls.Add(this.axMediaPlayer);
            this.Name = "AlarmClock";
            this.Text = "알람시계";
            this.Load += new System.EventHandler(this.AlarmClock_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.AlarmClock_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.axMediaPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private AxWMPLib.AxWindowsMediaPlayer axMediaPlayer;
        private System.Windows.Forms.ComboBox cbHour;
        private System.Windows.Forms.ComboBox cbMinute;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btSetAlarm;
        private System.Windows.Forms.TextBox txtAlarmView;
        private System.Windows.Forms.Timer timer2;
    }
}

