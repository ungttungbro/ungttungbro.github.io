﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace AlarmClock
{
    public partial class AlarmClock : Form
    {
        Clock clk = new Clock();    // Clock Class
        String[] AlarmTime;         // 알람시간 배열
        bool bMovieAction = false;  // 액션유무

        public AlarmClock()
        {
            InitializeComponent();
            initializeAlarm();
        }

        private void AlarmClock_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);

            axMediaPlayer.uiMode = "none";
        }

        private void AlarmClock_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            clk.DrawClock(g);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Text = "아날로그 시계 - " + DateTime.Now.ToShortDateString();
            Invalidate();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (!bMovieAction)
            {
                if (AlarmTime[0] == DateTime.Now.Hour.ToString() &&
                    AlarmTime[1] == DateTime.Now.Minute.ToString())
                {
                    axMediaPlayer.URL = "Alarm.avi";
                    axMediaPlayer.Ctlcontrols.play();

                    bMovieAction = true;
                }
            }
        }


        // 알람설정 버튼
        private void btSetAlarm_Click(object sender, EventArgs e)
        {
            writeAlarmDataFile();
            bMovieAction = false;

            initializeAlarm();
        }


        // 알람설정파일 기록
        private Boolean writeAlarmDataFile()
        {
            String Hour = cbHour.Text;
            String Minute = cbMinute.Text;

            String WriteStr = Hour + "/" + Minute;

            string fileName = "AlarmData.dat";

            try
            {
                FileStream FS = new FileStream(fileName, FileMode.Create);
                StreamWriter W = new StreamWriter(FS);

                W.WriteLine(WriteStr);

                W.Flush();
                FS.Close();
            }
            catch (Exception e)
            {
                return false;
                //MessageBox.Show(e.ToString());
            }

            return true;
        }


        // 알람설정파일 리드
        private Boolean readAlarmDataFile()
        {
            string fileName = "AlarmData.dat";
            
            try
            {
                FileStream FS = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                StreamReader R = new StreamReader(FS);

                String str = R.ReadLine();

                AlarmTime = str.Split('/');

                R.Close();
                FS.Close();
            }
            catch (Exception e)
            {
                return false;
                //MessageBox.Show(e.ToString());
            }

            return true;
        }


        // 프로그램 초기화
        private void initializeAlarm()
        {
            for (int i = 1; i < 25; i++)
            {
                cbHour.Items.Add(i);
            }

            for (int j = 1; j < 61; j++)
            {
                cbMinute.Items.Add(j);
            }

            if (false == readAlarmDataFile())
            {
                writeAlarmDataFile();
                readAlarmDataFile();
            }

            cbHour.Text = AlarmTime[0];
            cbMinute.Text = AlarmTime[1];

            txtAlarmView.Text = AlarmTime[0] + " 시" + AlarmTime[1] + " 분";
        }        
    }
}
