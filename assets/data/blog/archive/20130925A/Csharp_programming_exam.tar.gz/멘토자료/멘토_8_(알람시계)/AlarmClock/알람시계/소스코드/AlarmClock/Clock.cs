﻿using System;
using System.Drawing;

public class Clock
{
    private float x = 0;
    private float y = 0;    
    private float t = 0;

    private int h = 0;
    private int m = 0;
    private int s = 0;

    public Clock()
    {       
    }


    // 초침
    private void SecondLine(Graphics g, Pen second)
    {
        this.s = DateTime.Now.Second;
        this.t = this.s * 6 - 90;

        Change(70, this.t);

        g.DrawLine(second, 0, 0, this.x, this.y);
    }


    // 분침
    private void MinuteLine(Graphics g, Pen minute)
    {
        this.m = DateTime.Now.Minute;
        this.t = (this.m * 6 - 90) + (this.s * 0.1f);

        Change(80, this.t);

        g.DrawLine(minute, 0, 0, this.x, this.y);
    }


    // 시침
    private void HourLine(Graphics g, Pen hour)
    {
        this.h = DateTime.Now.Hour;
        this.t = (this.h * 30 - 90) + (this.m * 0.5f);

        Change(60, this.t);

        g.DrawLine(hour, 0, 0, this.x, this.y);
    }


    // 시계숫자
    private void DrawClockNumber(Graphics g, Font font)
    {
        g.DrawString("1", font, Brushes.Green, 28, -72);
        g.DrawString("2", font, Brushes.Green, 56, -46);
        g.DrawString("3", font, Brushes.Green, 68, -10);
        g.DrawString("4", font, Brushes.Green, 56, 28);
        g.DrawString("5", font, Brushes.Green, 30, 54);
        g.DrawString("6", font, Brushes.Green, -10, 64);
        g.DrawString("7", font, Brushes.Green, -46, 54);
        g.DrawString("8", font, Brushes.Green, -74, 28);
        g.DrawString("9", font, Brushes.Green, -86, -10);
        g.DrawString("10", font, Brushes.Green, -76, -46);
        g.DrawString("11", font, Brushes.Green, -48, -72);
        g.DrawString("12", font, Brushes.Green, -14, -84);
    }


    // 시계몸통
    private void ClockCircle(Graphics g, Pen clock)
    {
        g.FillEllipse(Brushes.White, 10, 10, 200, 200);     // 시계 내부색
        g.DrawEllipse(clock, 10, 10, 200, 200);             // 시계 테두리
        g.TranslateTransform(110, 110);                     // 원점좌표 이동
        g.FillEllipse(Brushes.Black, -4, -4, 8, 8);         // 시계 중심점

        Pen point1 = new Pen(Color.Green, 5);
        Pen point2 = new Pen(Color.DeepPink, 3);

        MinuteDot(g, point2);
        TimeDot(g, point1);
    }


    // 분점
    private void MinuteDot(Graphics g, Pen point)
    {
        for (int i = 0; i < 60; i++)
        {
            PointF p1 = new PointF();
            PointF p2 = new PointF();

            Change(87, i * 6);
            p1.X = this.x;
            p1.Y = this.y;

            Change(93, i * 6);
            p2.X = this.x;
            p2.Y = this.y;

            g.DrawLine(point, p1, p2);
        }
    }


    //시점
    private void TimeDot(Graphics g, Pen point)
    {
        for (int i = 1; i < 13; i++)
        {
            PointF p1 = new PointF();
            PointF p2 = new PointF();

            Change(85, i * 30);
            p1.X = this.x;
            p1.Y = this.y;

            Change(95, i * 30);
            p2.X = this.x;
            p2.Y = this.y;

            g.DrawLine(point, p1, p2);
        }
    }


    // 직각과표 계산
    private void Change(float radius, float theta)         // 구 좌표를 직작 좌표로
    {
        double x2 = radius * Math.Cos(theta / 180 * Math.PI);
        double y2 = radius * Math.Sin(theta / 180 * Math.PI);
        this.x = (float)x2;
        this.y = (float)y2;
    }


    // 시계 그리기
    public void DrawClock(Graphics g)
    {
        Pen clock = new Pen(Brushes.Azure, 3);
        ClockCircle(g, clock);

        Font font = new Font("휴먼편지체", 15);
        DrawClockNumber(g, font);

        Pen hour = new Pen(Color.Black, 3);
        hour.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
        HourLine(g, hour);

        Pen minute = new Pen(Color.Black, 3);
        minute.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
        MinuteLine(g, minute);

        Pen second = new Pen(Color.Silver, 3);
        second.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
        SecondLine(g, second);
    }
}