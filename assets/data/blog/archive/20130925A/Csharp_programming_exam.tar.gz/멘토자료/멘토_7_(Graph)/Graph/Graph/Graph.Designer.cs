﻿namespace Graph
{
    partial class frmGraph
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnDraw = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.lbName = new System.Windows.Forms.Label();
            this.lbValue = new System.Windows.Forms.Label();
            this.btADD = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.lsList = new System.Windows.Forms.ListBox();
            this.lsValue = new System.Windows.Forms.ListBox();
            this.btDelete = new System.Windows.Forms.Button();
            this.rblinegraph = new System.Windows.Forms.RadioButton();
            this.rbbargraph = new System.Windows.Forms.RadioButton();
            this.btChange = new System.Windows.Forms.Button();
            this.btExit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnDraw
            // 
            this.pnDraw.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnDraw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnDraw.Location = new System.Drawing.Point(9, 12);
            this.pnDraw.Name = "pnDraw";
            this.pnDraw.Size = new System.Drawing.Size(500, 488);
            this.pnDraw.TabIndex = 0;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(54, 14);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(144, 21);
            this.txtName.TabIndex = 1;
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(54, 41);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(144, 21);
            this.txtValue.TabIndex = 2;
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(11, 17);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(37, 12);
            this.lbName.TabIndex = 3;
            this.lbName.Text = "이름 :";
            // 
            // lbValue
            // 
            this.lbValue.AutoSize = true;
            this.lbValue.Location = new System.Drawing.Point(11, 44);
            this.lbValue.Name = "lbValue";
            this.lbValue.Size = new System.Drawing.Size(25, 12);
            this.lbValue.TabIndex = 4;
            this.lbValue.Text = "값 :";
            // 
            // btADD
            // 
            this.btADD.Location = new System.Drawing.Point(13, 68);
            this.btADD.Name = "btADD";
            this.btADD.Size = new System.Drawing.Size(85, 23);
            this.btADD.TabIndex = 5;
            this.btADD.Text = "추가";
            this.btADD.UseVisualStyleBackColor = true;
            this.btADD.Click += new System.EventHandler(this.btADD_Click);
            // 
            // btCancel
            // 
            this.btCancel.Location = new System.Drawing.Point(113, 68);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(85, 23);
            this.btCancel.TabIndex = 6;
            this.btCancel.Text = "취소";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // lsList
            // 
            this.lsList.FormattingEnabled = true;
            this.lsList.ItemHeight = 12;
            this.lsList.Location = new System.Drawing.Point(12, 15);
            this.lsList.Name = "lsList";
            this.lsList.Size = new System.Drawing.Size(94, 160);
            this.lsList.TabIndex = 7;
            // 
            // lsValue
            // 
            this.lsValue.FormattingEnabled = true;
            this.lsValue.ItemHeight = 12;
            this.lsValue.Location = new System.Drawing.Point(112, 15);
            this.lsValue.Name = "lsValue";
            this.lsValue.Size = new System.Drawing.Size(85, 160);
            this.lsValue.TabIndex = 8;
            // 
            // btDelete
            // 
            this.btDelete.Location = new System.Drawing.Point(12, 191);
            this.btDelete.Name = "btDelete";
            this.btDelete.Size = new System.Drawing.Size(185, 23);
            this.btDelete.TabIndex = 9;
            this.btDelete.Text = "삭제";
            this.btDelete.UseVisualStyleBackColor = true;
            this.btDelete.Click += new System.EventHandler(this.btDelete_Click);
            // 
            // rblinegraph
            // 
            this.rblinegraph.AutoSize = true;
            this.rblinegraph.Location = new System.Drawing.Point(55, 7);
            this.rblinegraph.Name = "rblinegraph";
            this.rblinegraph.Size = new System.Drawing.Size(99, 16);
            this.rblinegraph.TabIndex = 10;
            this.rblinegraph.TabStop = true;
            this.rblinegraph.Text = "꺽은선 그래프";
            this.rblinegraph.UseVisualStyleBackColor = true;
            // 
            // rbbargraph
            // 
            this.rbbargraph.AutoSize = true;
            this.rbbargraph.Location = new System.Drawing.Point(55, 29);
            this.rbbargraph.Name = "rbbargraph";
            this.rbbargraph.Size = new System.Drawing.Size(87, 16);
            this.rbbargraph.TabIndex = 11;
            this.rbbargraph.TabStop = true;
            this.rbbargraph.Text = "막대 그래프";
            this.rbbargraph.UseVisualStyleBackColor = true;
            this.rbbargraph.CheckedChanged += new System.EventHandler(this.rbLine_CheckedChanged);
            // 
            // btChange
            // 
            this.btChange.Location = new System.Drawing.Point(67, 54);
            this.btChange.Name = "btChange";
            this.btChange.Size = new System.Drawing.Size(75, 23);
            this.btChange.TabIndex = 12;
            this.btChange.Text = "변경";
            this.btChange.UseVisualStyleBackColor = true;
            this.btChange.Click += new System.EventHandler(this.btChange_Click);
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(537, 478);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(185, 23);
            this.btExit.TabIndex = 13;
            this.btExit.Text = "끝내기";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btCancel);
            this.groupBox1.Controls.Add(this.btADD);
            this.groupBox1.Controls.Add(this.lbValue);
            this.groupBox1.Controls.Add(this.lbName);
            this.groupBox1.Controls.Add(this.txtValue);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Location = new System.Drawing.Point(524, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 104);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btDelete);
            this.groupBox2.Controls.Add(this.lsValue);
            this.groupBox2.Controls.Add(this.lsList);
            this.groupBox2.Location = new System.Drawing.Point(525, 120);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 228);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btChange);
            this.groupBox3.Controls.Add(this.rbbargraph);
            this.groupBox3.Controls.Add(this.rblinegraph);
            this.groupBox3.Location = new System.Drawing.Point(525, 356);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(207, 83);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // frmGraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 515);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.pnDraw);
            this.Name = "frmGraph";
            this.Text = "그래프 그리기";            
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnDraw;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label lbValue;
        private System.Windows.Forms.Button btADD;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.ListBox lsList;
        private System.Windows.Forms.ListBox lsValue;
        private System.Windows.Forms.Button btDelete;
        private System.Windows.Forms.RadioButton rblinegraph;
        private System.Windows.Forms.RadioButton rbbargraph;
        private System.Windows.Forms.Button btChange;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

