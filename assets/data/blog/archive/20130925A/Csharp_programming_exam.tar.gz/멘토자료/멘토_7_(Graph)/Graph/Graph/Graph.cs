﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Graph
{
    public partial class frmGraph : Form
    {
        private int baseX = 50;
        private int limitX = 450;
        private int baseY = 30;
        private int limitY = 430;
       
        public frmGraph()
        {
            InitializeComponent();
        }

        private void rbLine_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtValue.Text = "";
        }

        private void btADD_Click(object sender, EventArgs e)
        {
            lsList.Items.Add(txtName.Text);
            lsValue.Items.Add(txtValue.Text);

            btCancel_Click(sender, e);
        }

        private void btDelete_Click(object sender, EventArgs e)
        {
            if (lsList.SelectedIndex == -1)
            {
                return;
            }

            int idx = lsList.SelectedIndex;

            lsList.Items.RemoveAt(idx);
            lsValue.Items.RemoveAt(idx);
        }

        private void btChange_Click(object sender, EventArgs e)
        {
            if (rblinegraph.Checked == true)
            {
                lineGraph();
            }
            else if (rbbargraph.Checked == true)
            {
                BarGraph();
            }
        }

        private void lineGraph()
        {
            pnDraw.Refresh();

            // Graphics 객체 생성
            Graphics myGraphics = pnDraw.CreateGraphics();
            
            Pen myPen = new Pen(Color.Black);

            int[] x = new int[10];
            int[] y = new int[10];

            int cnt = lsList.Items.Count;

            if (cnt == 0) 
                return;


            // 기준 선 그리기 |_
            myGraphics.DrawLine(myPen, baseX, limitY, limitX, limitY);
            myGraphics.DrawLine(myPen, baseX, limitY, baseX, baseY);


            // 좌표 따고 점찍기 ㅋ
            for (int i = 0; i < cnt; i++)
            {
                x[i] = ((limitX - baseX) * (i + 1) / (cnt + 1)) + baseX;
                y[i] = limitY - Int32.Parse(lsValue.Items[i].ToString());
                myGraphics.DrawEllipse(myPen, x[i] - 2, y[i] - 2, 4, 4);
                myGraphics.DrawString(lsList.Items[i].ToString(),
                    new Font("Times New Roman", 10),
                    new SolidBrush(Color.Black),
                    new Point(x[i], limitY));
            }


            // 꺽은선 그래프 그리기
            for (int i = 0; i < cnt - 1; i++)
            {
                myGraphics.DrawBezier(new Pen(Color.Blue), x[i], y[i], x[i], y[i],
                    x[i + 1], y[i + 1], x[i + 1], y[i + 1]);
            }

        }


        private void BarGraph()
        {
            pnDraw.Refresh();
            Graphics myGraphics = pnDraw.CreateGraphics();
            Pen myPen = new Pen(Color.Black);

            int[] x = new int[10];
            int[] y = new int[10];

            int cnt = lsList.Items.Count;

            if (cnt == 0) 
                return;


            int space = ((limitX - baseX) / (cnt + 1));

            // 기준 선 그리기
            myGraphics.DrawLine(myPen, baseX, limitY, limitX, limitY);
            myGraphics.DrawLine(myPen, baseX, limitY, baseX, baseY);


            // 좌표 따고 점찍기 ㅋ
            for (int i = 0; i < cnt; i++)
            {
                int yy = Int32.Parse(lsValue.Items[i].ToString());
                x[i] = ((limitX - baseX) * (i + 1) / (cnt + 1)) + baseX;
                y[i] = limitY - yy;
                myGraphics.DrawRectangle(new Pen(Brushes.DarkBlue), x[i] - space / 2, y[i], space, yy);                
                myGraphics.DrawString(lsList.Items[i].ToString(),
                    new Font("Times New Roman", 10),
                    new SolidBrush(Color.Black),
                    new Point(x[i], limitY));
            }
        }
    }
}
