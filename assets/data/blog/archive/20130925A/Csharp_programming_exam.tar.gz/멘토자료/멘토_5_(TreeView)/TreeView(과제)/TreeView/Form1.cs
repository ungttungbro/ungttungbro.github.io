﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TreeView
{
    public partial class Family_Form : Form
    {
        public Family_Form()
        {
            InitializeComponent();
        }

        private void button_FirstMan_Click(object sender, EventArgs e)
        {
            listView_Find_List.Clear();
            InitListControl();

            ProcessTree("장남");
        }

        private void button_FirstWoman_Click(object sender, EventArgs e)
        {
            listView_Find_List.Clear();
            InitListControl();

            ProcessTree("장녀");
        }

        private void button_man_Click(object sender, EventArgs e)
        {
            listView_Find_List.Clear();
            InitListControl();

            ProcessTree("남자");
        }

        private void button_woman_Click(object sender, EventArgs e)
        {
            listView_Find_List.Clear();
            InitListControl();

            ProcessTree("여자");
        }

        private void Family_Form_Load(object sender, EventArgs e)
        {
            InitListControl();
        }


        //-----------------------------------------------------------------------------

        private void addListControl(String ItemString, String [] SubItemString)
        {
            int Row = listView_Find_List.Items.Count;

            listView_Find_List.Items.Add(ItemString);
            listView_Find_List.Items[Row].SubItems.Add(SubItemString[0]);
            listView_Find_List.Items[Row].SubItems.Add(SubItemString[1]);
        }

        private void InitListControl()
        {
            listView_Find_List.View = View.Details;
            listView_Find_List.Columns.Add("이름", 100, HorizontalAlignment.Left);
            listView_Find_List.Columns.Add("신분", 80, HorizontalAlignment.Center);
            listView_Find_List.Columns.Add("성별", 80, HorizontalAlignment.Center);
        }

       
        private void ProcessTree(string Query)
        {
            // 루트 노드들에 대해서 처리
            TreeNodeCollection nodes = treeView_Family.Nodes;

            foreach (TreeNode n in nodes)
            {
                ProcessNode(n, Query);
            }
        }

        private void ProcessNode(TreeNode treeNode, string Query)
        {
            if (treeNode.Tag != null && 
                treeNode.Tag.ToString().IndexOf('/') > -1)
            {
                String[] TagData = treeNode.Tag.ToString().Split('/');

                if (TagData[0] == Query || TagData[1] == Query)
                {
                    addListControl(treeNode.Text, TagData);
                }
            }

            // 자식 노드들에 대해 똑같은 방식으로 처리
            foreach (TreeNode tn in treeNode.Nodes)
            {
                ProcessNode(tn, Query);
            }
        }
    }
}
