﻿namespace TreeView
{
    partial class Family_Form
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("장영완");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("장영숙");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("안순의");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("장관수", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("가족관계", new System.Windows.Forms.TreeNode[] {
            treeNode4});
            this.treeView_Family = new System.Windows.Forms.TreeView();
            this.button_FirstMan = new System.Windows.Forms.Button();
            this.button_FirstWoman = new System.Windows.Forms.Button();
            this.button_man = new System.Windows.Forms.Button();
            this.button_woman = new System.Windows.Forms.Button();
            this.listView_Find_List = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // treeView_Family
            // 
            this.treeView_Family.Location = new System.Drawing.Point(12, 12);
            this.treeView_Family.Name = "treeView_Family";
            treeNode1.Name = "장영완";
            treeNode1.Tag = "장남/남자";
            treeNode1.Text = "장영완";
            treeNode2.Name = "장영숙";
            treeNode2.Tag = "장녀/여자";
            treeNode2.Text = "장영숙";
            treeNode3.Name = "안순희";
            treeNode3.Tag = "처/여자";
            treeNode3.Text = "안순의";
            treeNode4.Name = "장관수";
            treeNode4.Tag = "호주/남자";
            treeNode4.Text = "장관수";
            treeNode5.Name = "Family_Relation";
            treeNode5.Text = "가족관계";
            this.treeView_Family.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode5});
            this.treeView_Family.Size = new System.Drawing.Size(195, 221);
            this.treeView_Family.TabIndex = 0;
            // 
            // button_FirstMan
            // 
            this.button_FirstMan.Location = new System.Drawing.Point(218, 12);
            this.button_FirstMan.Name = "button_FirstMan";
            this.button_FirstMan.Size = new System.Drawing.Size(97, 55);
            this.button_FirstMan.TabIndex = 1;
            this.button_FirstMan.Text = "장남";
            this.button_FirstMan.UseVisualStyleBackColor = true;
            this.button_FirstMan.Click += new System.EventHandler(this.button_FirstMan_Click);
            // 
            // button_FirstWoman
            // 
            this.button_FirstWoman.Location = new System.Drawing.Point(218, 73);
            this.button_FirstWoman.Name = "button_FirstWoman";
            this.button_FirstWoman.Size = new System.Drawing.Size(97, 50);
            this.button_FirstWoman.TabIndex = 2;
            this.button_FirstWoman.Text = "장녀";
            this.button_FirstWoman.UseVisualStyleBackColor = true;
            this.button_FirstWoman.Click += new System.EventHandler(this.button_FirstWoman_Click);
            // 
            // button_man
            // 
            this.button_man.Location = new System.Drawing.Point(218, 129);
            this.button_man.Name = "button_man";
            this.button_man.Size = new System.Drawing.Size(97, 48);
            this.button_man.TabIndex = 3;
            this.button_man.Text = "남자";
            this.button_man.UseVisualStyleBackColor = true;
            this.button_man.Click += new System.EventHandler(this.button_man_Click);
            // 
            // button_woman
            // 
            this.button_woman.Location = new System.Drawing.Point(218, 183);
            this.button_woman.Name = "button_woman";
            this.button_woman.Size = new System.Drawing.Size(97, 50);
            this.button_woman.TabIndex = 4;
            this.button_woman.Text = "여자";
            this.button_woman.UseVisualStyleBackColor = true;
            this.button_woman.Click += new System.EventHandler(this.button_woman_Click);
            // 
            // listView_Find_List
            // 
            this.listView_Find_List.Location = new System.Drawing.Point(13, 240);
            this.listView_Find_List.Name = "listView_Find_List";
            this.listView_Find_List.Size = new System.Drawing.Size(302, 105);
            this.listView_Find_List.TabIndex = 5;
            this.listView_Find_List.UseCompatibleStateImageBehavior = false;
            this.listView_Find_List.View = System.Windows.Forms.View.Details;
            // 
            // Family_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 357);
            this.Controls.Add(this.listView_Find_List);
            this.Controls.Add(this.button_woman);
            this.Controls.Add(this.button_man);
            this.Controls.Add(this.button_FirstWoman);
            this.Controls.Add(this.button_FirstMan);
            this.Controls.Add(this.treeView_Family);
            this.Name = "Family_Form";
            this.Text = "가족관계 트리뷰";
            this.Load += new System.EventHandler(this.Family_Form_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView_Family;
        private System.Windows.Forms.Button button_FirstMan;
        private System.Windows.Forms.Button button_FirstWoman;
        private System.Windows.Forms.Button button_man;
        private System.Windows.Forms.Button button_woman;
        private System.Windows.Forms.ListView listView_Find_List;
    }
}

