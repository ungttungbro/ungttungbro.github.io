﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace peoplesearch
{
    public partial class frmPeoepleSearch : Form
    {
        public frmPeoepleSearch()
        {
            InitializeComponent();
        }

        private void frmPeoepleSearch_Load(object sender, EventArgs e)
        {
            InitListControl();
            tvPeople.ExpandAll();            
        }

        private void btSearch_Click(object sender, EventArgs e)
        {
            InitListControl();

            String Query = txtSearch.Text;
            ProcessTree(Query);
        }


        //---------------------------------------------------------------

        private void addListControl(String item, String[] SubItem)
        {
            int Row = lvPoeple.Items.Count;

            lvPoeple.Items.Add(item);
            lvPoeple.Items[Row].SubItems.Add(SubItem[0]);
            lvPoeple.Items[Row].SubItems.Add(SubItem[1]);
            lvPoeple.Items[Row].SubItems.Add(SubItem[2]);
            lvPoeple.Items[Row].SubItems.Add(SubItem[3]);
        }

        private void InitListControl()
        {
            lvPoeple.Clear();

            lvPoeple.View = View.Details;

            lvPoeple.Columns.Add("학번", 80, HorizontalAlignment.Left);
            lvPoeple.Columns.Add("이름", 80, HorizontalAlignment.Center);
            lvPoeple.Columns.Add("전화번호", 240, HorizontalAlignment.Center);
            lvPoeple.Columns.Add("성별", 80, HorizontalAlignment.Center);
            lvPoeple.Columns.Add("신분", 80, HorizontalAlignment.Center);
        }

        private void ProcessTree(string Query)
        {
            // 루트 노드들에 대해서 처리
            TreeNodeCollection nodes = tvPeople.Nodes;

            foreach (TreeNode n in nodes)
            {
                ProcessNode(n, Query);
            }
        }

        private void ProcessNode(TreeNode treeNode, string Query)
        {
            if (treeNode.Text != "학생정보" &&
                treeNode.Text == Query)
            {
                String nodeData = "";

                // 자식 노드들에 대해 똑같은 방식으로 처리
                foreach (TreeNode tn in treeNode.Nodes)
                {
                    nodeData += tn.Text + "/";
                    ProcessNode(tn, Query);
                }

                String[] studentData = nodeData.Split('/');

                addListControl(treeNode.Text, studentData);

                displayImage(treeNode.Text);
            }
            else
            {
                // 자식 노드들에 대해 똑같은 방식으로 처리
                foreach (TreeNode tn in treeNode.Nodes)
                {             
                    ProcessNode(tn, Query);
                }
            }
        }

        private void displayImage(String studentNo)
        {
            Bitmap Image = new Bitmap("..\\..\\Resources\\" + studentNo + ".jpg");
            picPoeple.Image = Image;
            picPoeple.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                btSearch_Click(sender, e);
            }     
        }
    }
}
