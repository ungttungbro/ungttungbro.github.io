﻿namespace peoplesearch
{
    partial class frmPeoepleSearch
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode111 = new System.Windows.Forms.TreeNode("장영완");
            System.Windows.Forms.TreeNode treeNode112 = new System.Windows.Forms.TreeNode("010-2880-1234");
            System.Windows.Forms.TreeNode treeNode113 = new System.Windows.Forms.TreeNode("남자");
            System.Windows.Forms.TreeNode treeNode114 = new System.Windows.Forms.TreeNode("대학원생");
            System.Windows.Forms.TreeNode treeNode115 = new System.Windows.Forms.TreeNode("20126087", new System.Windows.Forms.TreeNode[] {
            treeNode111,
            treeNode112,
            treeNode113,
            treeNode114});
            System.Windows.Forms.TreeNode treeNode116 = new System.Windows.Forms.TreeNode("장영만");
            System.Windows.Forms.TreeNode treeNode117 = new System.Windows.Forms.TreeNode("010-1234-1234");
            System.Windows.Forms.TreeNode treeNode118 = new System.Windows.Forms.TreeNode("남자");
            System.Windows.Forms.TreeNode treeNode119 = new System.Windows.Forms.TreeNode("학부생");
            System.Windows.Forms.TreeNode treeNode120 = new System.Windows.Forms.TreeNode("20111234", new System.Windows.Forms.TreeNode[] {
            treeNode116,
            treeNode117,
            treeNode118,
            treeNode119});
            System.Windows.Forms.TreeNode treeNode121 = new System.Windows.Forms.TreeNode("학생정보", new System.Windows.Forms.TreeNode[] {
            treeNode115,
            treeNode120});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPeoepleSearch));
            this.tvPeople = new System.Windows.Forms.TreeView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btSearch = new System.Windows.Forms.Button();
            this.lvPoeple = new System.Windows.Forms.ListView();
            this.picPoeple = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picPoeple)).BeginInit();
            this.SuspendLayout();
            // 
            // tvPeople
            // 
            this.tvPeople.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tvPeople.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tvPeople.Font = new System.Drawing.Font("돋움", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tvPeople.Location = new System.Drawing.Point(12, 40);
            this.tvPeople.Name = "tvPeople";
            treeNode111.Name = "Name";
            treeNode111.Text = "장영완";
            treeNode112.Name = "phone";
            treeNode112.Text = "010-2880-1234";
            treeNode113.Name = "gender";
            treeNode113.Text = "남자";
            treeNode114.Name = "graduate";
            treeNode114.Text = "대학원생";
            treeNode115.Name = "studentNo";
            treeNode115.Text = "20126087";
            treeNode116.Name = "Name";
            treeNode116.Text = "장영만";
            treeNode117.Name = "phone";
            treeNode117.Text = "010-1234-1234";
            treeNode118.Name = "gender";
            treeNode118.Text = "남자";
            treeNode119.Name = "graduate";
            treeNode119.Text = "학부생";
            treeNode120.Name = "studentNo";
            treeNode120.Text = "20111234";
            treeNode121.Name = "학생정보";
            treeNode121.Text = "학생정보";
            this.tvPeople.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode121});
            this.tvPeople.Size = new System.Drawing.Size(210, 235);
            this.tvPeople.TabIndex = 0;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.MistyRose;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Font = new System.Drawing.Font("돋움", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtSearch.Location = new System.Drawing.Point(12, 13);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(153, 22);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btSearch
            // 
            this.btSearch.BackColor = System.Drawing.Color.Lavender;
            this.btSearch.Location = new System.Drawing.Point(171, 13);
            this.btSearch.Name = "btSearch";
            this.btSearch.Size = new System.Drawing.Size(51, 21);
            this.btSearch.TabIndex = 2;
            this.btSearch.Text = "검색";
            this.btSearch.UseVisualStyleBackColor = false;
            this.btSearch.Click += new System.EventHandler(this.btSearch_Click);
            // 
            // lvPoeple
            // 
            this.lvPoeple.BackColor = System.Drawing.Color.LightBlue;
            this.lvPoeple.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvPoeple.GridLines = true;
            this.lvPoeple.Location = new System.Drawing.Point(12, 281);
            this.lvPoeple.Name = "lvPoeple";
            this.lvPoeple.Size = new System.Drawing.Size(582, 163);
            this.lvPoeple.TabIndex = 3;
            this.lvPoeple.UseCompatibleStateImageBehavior = false;
            // 
            // picPoeple
            // 
            this.picPoeple.Image = ((System.Drawing.Image)(resources.GetObject("picPoeple.Image")));
            this.picPoeple.Location = new System.Drawing.Point(228, 13);
            this.picPoeple.Name = "picPoeple";
            this.picPoeple.Size = new System.Drawing.Size(366, 262);
            this.picPoeple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPoeple.TabIndex = 4;
            this.picPoeple.TabStop = false;
            // 
            // frmPeoepleSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(606, 456);
            this.Controls.Add(this.picPoeple);
            this.Controls.Add(this.lvPoeple);
            this.Controls.Add(this.btSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.tvPeople);
            this.MinimizeBox = false;
            this.Name = "frmPeoepleSearch";
            this.Text = "신상조회기";
            this.Load += new System.EventHandler(this.frmPeoepleSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picPoeple)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView tvPeople;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btSearch;
        private System.Windows.Forms.ListView lvPoeple;
        private System.Windows.Forms.PictureBox picPoeple;
    }
}

