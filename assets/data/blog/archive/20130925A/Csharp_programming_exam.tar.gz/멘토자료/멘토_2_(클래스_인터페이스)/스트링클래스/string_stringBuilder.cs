﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


/* string과 string builder의 속도차 */
namespace string_class
{
    class Program
    {
        static void Main(string[] args)
        {
            const int loop_count = 50000;
            long start = DateTime.Now.Ticks;
            String test = null;

            for (int i = 0; i < loop_count; i++)
            {
                test += "Data 들어갑니다.\n";
            }

            long end = DateTime.Now.Ticks;
            DateTime DT = new DateTime(end - start);
            Console.WriteLine("String 소요시간은 {0}초 입니다.", DT.Second);

            start = DateTime.Now.Ticks;
            StringBuilder test2 = new StringBuilder();

            for (int i = 0; i < loop_count; i++)
            {
                test2.Append("Data 들어갑니ㅏ.\n");
            }

            end = DateTime.Now.Ticks;
            DT = new DateTime(end - start);
            Console.WriteLine("String Builder 쇼요시간은 {0}초 입니다.", DT.Second);

            Console.WriteLine("Press Any Key....");
            Console.ReadLine();
        }
    }
}
