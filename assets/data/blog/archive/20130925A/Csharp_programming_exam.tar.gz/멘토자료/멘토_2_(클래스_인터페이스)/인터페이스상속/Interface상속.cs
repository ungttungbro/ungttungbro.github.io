﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interface_inhritance
{
    interface Haha
    {
        void great();
    }

    interface Great
    {
       void great();
    }

    interface Bye : Great, Haha
    {
        new void great();
        void bye();
    }

    class Greeting : Bye
    {
        public void great()
        {
            Console.WriteLine("안녕하세요.");
        }

        public void bye()
        {
            Console.WriteLine("안녕히가세요.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Greeting greeting = new Greeting();
            greeting.great();
            greeting.bye();
        }
    }
}
