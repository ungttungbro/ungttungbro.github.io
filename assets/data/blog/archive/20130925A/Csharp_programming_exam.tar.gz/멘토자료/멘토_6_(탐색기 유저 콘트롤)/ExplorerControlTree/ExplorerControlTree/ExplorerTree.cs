﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace ExplorerControlTree
{
    // SHFILEINFO 구조체
    [StructLayout(LayoutKind.Sequential)]
    public struct SHFILEINFO
    {
        public IntPtr hIcon;
        public IntPtr iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    }

    public partial class ExplorerTree : UserControl
    {
        private IntPtr hImgSmall;   // smallImage Ptr

        // Win32API CALL
        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, 
                                                    ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);

        private ListView lv = new ListView();   // ListView
        
        private int imgindex = 0;   // ImageIndex

        public ExplorerTree()
        {
            InitializeComponent();
        }

        // 노드 섵택후에 발생하는 이벤트
        private void tvExporer_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode node = e.Node;

            // imageindex에 현재 들어있는 이미지가 몇개 인지 count
            imgindex = imageList1.Images.Count;

            // 트리뷰에 subtree dir 뿌려줌
            SetListView(node.Name);
        }

        // 노드 확장전에 발생하는 이벤트
        private void tvExporer_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNode node = e.Node;

            // 서브트리 구성을 위해 populateTree 메소드 호출
            foreach (TreeNode child in node.Nodes)
            {
                PopulateTree(child);
            }
        }

        private void ExplorerTree_Load(object sender, EventArgs e)
        {
            // 초기화
            Initialize_Tree();
        }


        // 트리뷰 초기화
        private void Initialize_Tree()
        {
            tvExporer.Nodes.Clear();

            // 초기에는 드라이브만 보여준다
            DriveInfo[] drives = DriveInfo.GetDrives();

            foreach (DriveInfo drive in drives)
            {
                TreeNode newNode = new TreeNode(drive.ToString());
                newNode.Name = drive.ToString();

                // 아이콘 설정
                SetIcon(newNode.Name);

                tvExporer.Nodes.Add(newNode);
                PopulateTree(newNode);
            }
        }
        
        // 트리구조 설정
        private void PopulateTree(TreeNode node)
        {
            string path = node.Name;

            try
            {
                string[] subDirs = Directory.GetDirectories(path);

                // 아이콘 설정
                SetIcon(subDirs[0]);

                foreach (string subDir in subDirs)
                {
                    TreeNode newNode = new TreeNode();
                    newNode.Name = subDir;
                    newNode.Text = subDir.Substring(subDir.LastIndexOf('\\') + 1);
                    newNode.ImageIndex = 1;

                    node.Nodes.Add(newNode);
                }
            }
            catch (Exception)
            {
                node.Text += " <미디어없음>";
                //MessageBox.Show(node.Text);
            }
        }

        // 아이콘 설정
        public void SetIcon(string path)
        {
            SHFILEINFO shinfo = new SHFILEINFO();
            hImgSmall = SHGetFileInfo(path, 0, ref shinfo, (uint)Marshal.SizeOf(shinfo), 0x100 | 0x1);
            System.Drawing.Icon myIcon = System.Drawing.Icon.FromHandle(shinfo.hIcon);

            imageList1.Images.Add(myIcon);            
        }

        // 리스트뷰 설정
        private void SetListView(string path)
        {
            lv.Items.Clear();
            lv.SmallImageList = imageList1;

            try
            {
                foreach (string dir in Directory.GetDirectories(path))
                {
                    SetIcon(dir);

                    int nCnt = imageList1.Images.Count;

                    ListViewItem lvi = lv.Items.Add(
                        dir.Substring(dir.LastIndexOf('\\') + 1), imgindex++);

                    lvi.SubItems.Add("");
                    lvi.SubItems.Add("디렉토리");
                }

                foreach (string file in Directory.GetFiles(path))
                {
                    SetIcon(file);

                    int nCnt = imageList1.Images.Count;
                    
                    ListViewItem lvi = lv.Items.Add(
                        file.Substring(file.LastIndexOf('\\') + 1), imgindex++);

                    FileInfo finfo = new FileInfo(file);

                    lvi.SubItems.Add(finfo.Length.ToString());
                    lvi.SubItems.Add("파일");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString());
            }
        }

        // 리스트뷰 설정
        public void SetListView(ListView LV)
        {
            lv = LV;
        }
    }
}