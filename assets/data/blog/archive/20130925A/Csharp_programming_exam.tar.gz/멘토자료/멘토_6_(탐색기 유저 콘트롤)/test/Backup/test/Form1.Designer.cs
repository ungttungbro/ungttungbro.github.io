﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.explorerTree1 = new ExplorerControlTree.ExplorerTree();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // explorerTree1
            // 
            this.explorerTree1.Location = new System.Drawing.Point(13, 13);
            this.explorerTree1.Name = "explorerTree1";
            this.explorerTree1.Size = new System.Drawing.Size(296, 343);
            this.explorerTree1.TabIndex = 0;
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(316, 13);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(445, 343);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.List;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 368);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.explorerTree1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ExplorerControlTree.ExplorerTree explorerTree1;
        private System.Windows.Forms.ListView listView1;






    }
}

