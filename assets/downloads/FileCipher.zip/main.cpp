#include "./FileCipher/FileEncryption.h"
#include <stdio.h>
#include <iostream>

int main(void)
{
	FileEncryption file;
	file.setBufferSize(1024);
	
	// ���Ϻ���
	//file.copyFile("old.mp4", "new.mp4", "rb", "wb");
	
	// ���� ��ȣȭ
	if (!file.encryptFile((BYTE*)"1234", (BYTE*)"ivector", 7, "old.mp4", "new.ef", "rb", "wb")) {
		std::cout << file.getExceptionMessage() << std::endl;
		system("pause");
		return 0;
	}
	
	// ���� ��ȣȭ
	/*if (!file.decryptFile((BYTE*)"1234", (BYTE*)"ivector", 7, "new.ef", "newOK.mp4", "rb", "wb")) {
		std::cout << file.getExceptionMessage() << std::endl;
		system("pause");
		return 0;
	}*/

	std::cout << "Complate !!!" << std::endl;

	return 0;
}