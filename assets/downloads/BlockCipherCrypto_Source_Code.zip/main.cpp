#include "./BlockCipherCrypto/BlockCipherCrypto.hpp"
#include <iostream>

using namespace BlockCipherCrypto;

// �迭 ũ�� ����
size_t arraySize(BYTE* data, size_t arraySize)
{
	size_t dataLength = 0;

	while(1) {
		if (data[((arraySize - 1) - dataLength)] != '\0')
			break;

		if (dataLength == (arraySize - 1))
			break;

		dataLength++;
	}

	size_t ret = (arraySize - dataLength);

	return ret;
}


template <typename X>
bool encrypt_CBC_CTS_RandomIV(X& s, const BYTE* userIV, const size_t userIVSize, BYTE* data, const size_t dataSize)
{
	s.generateInitialVector(userIV, userIVSize, InitialVectorMode::RANDOM);

	s.encryptCBC_CTS(data, dataSize);
	memcpy(data+dataSize, s.getInitialVector(), s.getInitialVectorSize());

	return true;
}

template <typename X>
bool decrypt_CBC_CTS_RandomIV(X& s, BYTE* data, const size_t dataSize)
{
	BYTE initialVector[MAXBLOCKSIZE];

	memcpy(initialVector, data+(dataSize -  s.getInitialVectorSize()), s.getInitialVectorSize());

	s.setInitialVector(initialVector);

	memset(data + (dataSize -  s.getInitialVectorSize()), 0x00, s.getInitialVectorSize());

	s.decryptCBC_CTS(data, (dataSize - s.getInitialVectorSize()));

	return true;
}


template <typename X>
bool encrypt_CBC_MAC(X& s, BYTE* data, const size_t dataSize, const BYTE* userKey, const size_t userKeySize, 
							const BYTE* userIV, const size_t userIVSize, const int padType = BlockCipherPadType::NONE)
{
	if (false == s.encryptCBC(data, dataSize, padType))
		return false;

	BYTE* message = new BYTE[(userKeySize + userIVSize)];

	memcpy(message, userKey, userKeySize);
	memcpy(message + userKeySize, userIV, userIVSize);

	// �޽��� �����ڵ�
	bool isEncrypt = s.generateMAC(data, dataSize, message, (userKeySize + userIVSize));
	memcpy(data + arraySize(data, 200), s.getMac(), s.getMacSize());

	DELETE(message);

	return isEncrypt;
}


template <typename X>
bool decrypt_CBC_MAC(X& s, BYTE* data, const size_t dataSize, const BYTE* userKey, const size_t userKeySize, 
							const BYTE* userIV, const size_t userIVSize,  const int padType = BlockCipherPadType::NONE)
{
	BYTE* message = new BYTE[(userKeySize + userIVSize)];

	memcpy(message, userKey, userKeySize);
	memcpy(message + userKeySize, userIV, userIVSize);

	// MAC ����
	BYTE mac[MAXMACSIZE];
	memcpy(mac, data + (dataSize - s.getMacSize()), s.getMacSize());

	if (!s.authenticateMAC(mac, data, dataSize, message, (userKeySize + userIVSize))) {
		std::cout << s.getExceptionSymbol() << std::endl;
		return false;
	}
	memset(data + (dataSize - s.getMacSize()), NULL, s.getMacSize());

	bool isDecrypt = s.decryptCBC(data, (dataSize - s.getMacSize()), padType);

	DELETE(message);

	return isDecrypt;
}


template <typename X>
bool encrypt_CFB_NONCE(X& s, BYTE* data, const size_t dataSize, const BYTE* userIV, const size_t userIVSize,  
								const int padType = BlockCipherPadType::NONE)
{
	s.generateInitialVector(userIV, userIVSize, InitialVectorMode::NONCE);
	s.encryptCFB(data, dataSize);
	memcpy(data+dataSize, s.getNonce(), s.getNonceSize());
	
	return true;
}


template <typename X>
bool decrypt_CFB_NONCE(X& s, BYTE* data, const size_t dataSize, const BYTE* userIV, const size_t userIVSize,  
								const int padType = BlockCipherPadType::NONE)
{
	BYTE nonce[MAXNONCESIZE];

	memcpy(nonce, data+(dataSize -  s.getNonceSize()), s.getNonceSize());
	memset(data+(dataSize -  s.getNonceSize()), NULL, s.getNonceSize());

	s.generateInitialVector(userIV, userIVSize, InitialVectorMode::IV);
	s.setNonceInitialVector(nonce);

	s.decryptCFB(data, (dataSize - s.getNonceSize()));
	
	return true;
}


template <typename X>
bool encrypt_CTR_NONCE_COUNTER(X& s, BYTE* data, const size_t dataSize, const BYTE* userIV, const size_t userIVSize,  
								const int padType = BlockCipherPadType::NONE)
{
	s.generateInitialVector(userIV, userIVSize, InitialVectorMode::NONCE_COUNTER);
	s.encryptCTR(data, dataSize);
	memcpy(data+dataSize, s.getNonce(), s.getNonceSize());
	
	return true;
}


template <typename X>
bool decrypt_CTR_NONCE_COUNTER(X& s, BYTE* data, const size_t dataSize, const BYTE* userIV, const size_t userIVSize,  
								const int padType = BlockCipherPadType::NONE)
{
	BYTE nonce[MAXNONCESIZE];

	memcpy(nonce, data+(dataSize -  s.getNonceSize()), s.getNonceSize());
	memset(data+(dataSize -  s.getNonceSize()), NULL, s.getNonceSize());

	s.setNonceCounterInitialVector(nonce);

	return true;
}


// ���Ͼ�ȣ ��ȣȭ
template <typename X>
bool decryptBlockCipher(const int mode, X& s,
					const BYTE* userKey, const size_t userKeySize,
					const BYTE* userIV, const size_t userIVSize,
					BYTE* data, const size_t dataSize, 
					const int padType = BlockCipherPadType::NONE)
{
	s.generatePrivateKey(userKey, userKeySize);

	bool isDecrypt = false;
	switch(mode) {
	case BlockCipherMode::ECB:
		isDecrypt = s.decryptECB(data, dataSize, padType);	break;
	case BlockCipherMode::ECB_CTS:
		isDecrypt = s.decryptECB_CTS(data, dataSize);		break;
	case BlockCipherMode::CBC:
		s.generateInitialVector(userIV, userIVSize, InitialVectorMode::IV);
		isDecrypt = s.decryptCBC(data, dataSize, padType);
		break;
	case BlockCipherMode::CBC_CTS:
		isDecrypt = decrypt_CBC_CTS_RandomIV(s, data, dataSize);
		break;
	case BlockCipherMode::CBC_MAC:		
		isDecrypt = decrypt_CBC_MAC(s, data, dataSize, userKey, userKeySize, userIV, userIVSize, padType);
		break;
	case BlockCipherMode::CFB:
		isDecrypt = decrypt_CFB_NONCE(s, data, dataSize, userIV, userIVSize);
		break;
	case BlockCipherMode::OFB:
		s.generateInitialVector(userIV, userIVSize, InitialVectorMode::IV);
		isDecrypt = s.decryptOFB(data, dataSize);	break;
	case BlockCipherMode::COUNTER:
		isDecrypt = decrypt_CTR_NONCE_COUNTER(s, data, dataSize, userIV, userIVSize, padType);	break;
	default:
		isDecrypt = false;
		break;
	}

	return isDecrypt;
}


// ���Ͼ�ȣ ��ȣȭ
template <typename X>
bool encryptBlockCipher(const int mode, X& s,
						const BYTE* userKey, const size_t userKeySize,
						const BYTE* userIV, const size_t userIVSize,
						BYTE* data, const size_t dataSize, 
						const int padType = BlockCipherPadType::NONE)
{
	s.generatePrivateKey(userKey, userKeySize);

	bool isEncrypt = false;
	switch(mode) {
	case BlockCipherMode::ECB:
		isEncrypt = s.encryptECB(data, dataSize, padType);	break;
	case BlockCipherMode::ECB_CTS:
		isEncrypt = s.encryptECB_CTS(data, dataSize);		break;
	case BlockCipherMode::CBC:
		s.generateInitialVector(userIV, userIVSize, InitialVectorMode::IV);
		isEncrypt = s.encryptCBC(data, dataSize, padType);
		break;
	case BlockCipherMode::CBC_CTS:
		isEncrypt = encrypt_CBC_CTS_RandomIV(s, userIV, userIVSize, data, dataSize);
		break;
	case BlockCipherMode::CBC_MAC:
		isEncrypt = encrypt_CBC_MAC(s, data, dataSize, userKey, userKeySize, userIV, userIVSize, padType);
		break;
	case BlockCipherMode::CFB:
		isEncrypt = encrypt_CFB_NONCE(s, data, dataSize, userIV, userIVSize);
		break;
	case BlockCipherMode::OFB:
		s.generateInitialVector(userIV, userIVSize, InitialVectorMode::IV);
		isEncrypt = s.encryptOFB(data, dataSize);		break;
	case BlockCipherMode::COUNTER:
		isEncrypt = encrypt_CTR_NONCE_COUNTER(s, data, dataSize, userIV, userIVSize);	break;
	default:
		isEncrypt = false;
		break;
	}

	return isEncrypt;
}


// ���Ͼ�ȣ �׽�Ʈ
template <typename X>
void blockCipher(X& type, const int mode)
{
	BYTE userKey[] = "BlockCipherOperation_Algorithms_";
	BYTE iv[] = "__BlockCipherIV_";
	BYTE data[200] = "���Ͼ�ȣ ��� �˰����� Test �Դϴ�.\n��ȣ �˰������� DES(64, 128, 192), AES256, SEED256, ARIA(128, 192, 256) �˰������� ��� �Ͽ����ϴ�.";

	size_t keyLength = sizeof(userKey) / sizeof(userKey[0]);
	size_t ivLength = sizeof(iv) / sizeof(iv[0]);
	size_t plainDataLength = arraySize(data, 200);

	std::cout << "input Plain Data :  \n" << data << '\n' << std::endl;
	std::cout << "input Plain Data Length : " << plainDataLength << std::endl;

	
	// ��ȣȭ TEST
	bool isEncrypt = false;

	if (mode == BlockCipherMode::ECB || mode == BlockCipherMode::CBC || mode == BlockCipherMode::CBC_MAC) {
		isEncrypt = encryptBlockCipher(mode, type, userKey, keyLength, iv, ivLength, 
										data, plainDataLength, BlockCipherPadType::AnsiX923);
	} else {
		isEncrypt = encryptBlockCipher(mode, type, userKey, keyLength, iv, ivLength, data, plainDataLength);
	}
	
	if (true == isEncrypt) {
		std::cout << "Cipher Data Length : " << arraySize(data, 200) << std::endl;	
	} else {
		std::cout << "Exception : " << "��ȣȭ�� ���� �Ͽ����ϴ�." << std::endl;
	}

	//type.close();


	// ��ȣȭ
	size_t cipherDataLength = arraySize(data, 200);
	bool isDecrypt = false;
	if (mode == BlockCipherMode::ECB || mode == BlockCipherMode::CBC || mode == BlockCipherMode::CBC_MAC) {
		isDecrypt = decryptBlockCipher(mode, type, userKey, keyLength, iv, ivLength, 
										data, cipherDataLength, BlockCipherPadType::AnsiX923);
	} else {
		isDecrypt = decryptBlockCipher(mode, type, userKey, keyLength, iv, ivLength, data, cipherDataLength);
	}

	if (true == isDecrypt) {
		std::cout << "output Plain Data Length : " << arraySize(data, 200) << '\n' << std::endl;
		std::cout << "output Plain Data :  \n" << data << "\n\n" << std::endl;
	} else {
		std::cout << "Exception : " << "��ȣȭ�� ���� �Ͽ����ϴ�." << std::endl;
	}

	//type.close();
}


void AES256Test()
{
	BlockCipherOperator<CipherAES::AES256> blockCipherObj;

	std::cout << "----------------------- AES256-ECB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB);

	std::cout << "--------------------- AES256-ECB-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB_CTS);

	std::cout << "----------------------- AES256-CBC -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC);

	std::cout << "--------------------- AES256-CBC-MAC ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_MAC);

	std::cout << "--------------------- AES256-CBC-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_CTS);

	std::cout << "----------------------- AES256-CFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CFB);

	std::cout << "----------------------- AES256-OFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::OFB);

	std::cout << "----------------------- AES256-CTR -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::COUNTER);

	blockCipherObj.close();

	system("pause");
}


void SEED256Test()
{
	BlockCipherOperator<CipherSEED::SEED256> blockCipherObj;

	std::cout << "----------------------- SEED256-ECB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB);

	std::cout << "--------------------- SEED256-ECB-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB_CTS);

	std::cout << "----------------------- SEED256-CBC -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC);

	std::cout << "--------------------- SEED256-CBC-MAC ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_MAC);

	std::cout << "--------------------- SEED256-CBC-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_CTS);

	std::cout << "----------------------- SEED256-CFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CFB);

	std::cout << "----------------------- SEED256-OFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::OFB);

	std::cout << "----------------------- SEED256-CTR -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::COUNTER);

	blockCipherObj.close();

	system("pause");
}


void ARIATest()
{
	// Aria �˰������� 128, 192, 256 ��Ʈ�� �����Ѵ�.
	BlockCipherOperator<CipherARIA::ARIA> blockCipherObj(256);

	std::cout << "----------------------- ARIA-ECB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB);

	std::cout << "--------------------- ARIA-ECB-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB_CTS);

	std::cout << "----------------------- ARIA-CBC -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC);

	std::cout << "--------------------- ARIA-CBC-MAC ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_MAC);

	std::cout << "--------------------- ARIA-CBC-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_CTS);

	std::cout << "----------------------- ARIA-CFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CFB);

	std::cout << "----------------------- ARIA-OFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::OFB);

	std::cout << "----------------------- ARIA-CTR -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::COUNTER);

	blockCipherObj.close();

	system("pause");
}

void DESTest()
{
	// DES �˰������� 64(DES), 128(2DES), 192(3DES) ��Ʈ�� �����Ѵ�.
	BlockCipherOperator<CipherDES::DES> blockCipherObj(192);

	std::cout << "----------------------- DES-ECB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB);

	std::cout << "--------------------- DES-ECB-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::ECB_CTS);

	std::cout << "----------------------- DES-CBC -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC);

	std::cout << "--------------------- DES-CBC-MAC ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_MAC);

	std::cout << "--------------------- DES-CBC-CTS ---------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CBC_CTS);

	std::cout << "----------------------- DES-CFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::CFB);

	std::cout << "----------------------- DES-OFB -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::OFB);

	std::cout << "----------------------- DES-CTR -----------------------" << std::endl;
	blockCipher(blockCipherObj, BlockCipherMode::COUNTER);

	blockCipherObj.close();

	system("pause");
}


int main()
{	
	AES256Test();
	SEED256Test();
	ARIATest();
	DESTest();

    return 0;
}