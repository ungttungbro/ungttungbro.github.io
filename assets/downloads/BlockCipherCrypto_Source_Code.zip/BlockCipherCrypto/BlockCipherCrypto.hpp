/******************************************************************************************************
	�� ���̺귯���� ���Ͼ�ȣ ������� �̿��Ͽ� �Ϻ�ȣȭ�� �����մϴ�.
	�̿����� ������ main.cpp�� �����Ǿ� ������ �����Ͻø� �˴ϴ�.
	
	�����˰����� : AES256, SEED256, ARIA (128, 192, 256), DES (64, 128(2DES), 192(3DES))

	���� ���� ������ ��ϰ� ������ ������ �¿� ��� �� �ֽ��ϴ�. (VC++ 2010���� TEST)
	
	 * ECB (Electronic CodeBook)   - CTS ����
	 * CBC (Cipher-Block chaining) - CTS ����
	 * CFB (Cipher Feedback)
	 * OFB (Output Feedback)
	 * CTR (Counter)
	
	    ������ : �念�� [ jywan@naver.com ]
		����ó : blog.naver.com/jywan
		������ : 2014�� 9�� 28��
	  �������� : 0.93
********************************************************************************************************/

#ifndef _BlockCipherCrypto_H
#define _BlockCipherCrypto_H

#include "BlockCipherCryptoEnv.hpp"
#include "PsuedoRandomNumberGenerator.hpp"
#include "./BlockCipherAlgoritms/AES256/AES256.h"
#include "./BlockCipherAlgoritms/SEED256/SEED256.h"
#include "./BlockCipherAlgoritms/ARIA/ARIA.h"
#include "./BlockCipherAlgoritms/DES/DES.h"
#include "./HashAlgorithms/SHA2/SHA2.h"
#include <string>

using namespace BlockCipherCryptoEnv;

namespace BlockCipherCrypto
{
	// ���Ͼ�ȣ ��� Ŭ����
	template <typename X> class BlockCipherOperator
	{
	private:
		X blockCipher;											// Block Cipher Type
		CryptoContext ctx;										// Crypto Context
		PRNG::PsuedoRandomNumberGenerator prng;	// ����������
		CryptoBuffer buf;										// Crypto Buffer

		size_t pkSize;			// ���Ű ������
		size_t ivSize;			// ����� �̴ϼ� ������ ����
		size_t ctrSize;			// ī������ ����
		size_t blockSize;		// ���� ����
		size_t macSize;		// MAC ����
		size_t nonceSize;	// NONCE ����

		bool isGeneratePrivateKey;				// Ű ���� ����
		bool isGenerateInitialVector;			// IV ���� ����
		bool isGenerateCounterInitialVector;	// ī���� IV ��������
		bool isGenerateMAC;					// MAC ��������

		std::string exception;	// ����

	public:
		BlockCipherOperator(const BYTE* key, const int privateKeyBit = 0)
		{
			blockCipher.setBitMode(privateKeyBit);

			initialize();
			generateRoundKey(key);
		}

		BlockCipherOperator(const BYTE* key, const BYTE* iv, const int privateKeyBit = 0)
		{
			blockCipher.setBitMode(privateKeyBit);

			initialize();
			generateRoundKey(key);
			generateInitialVector(iv);
		}

		BlockCipherOperator(const int privateKeyBit)
		{
			blockCipher.setBitMode(privateKeyBit);
			initialize();
		}

		BlockCipherOperator()
		{
			initialize();
		}

		virtual ~BlockCipherOperator()
		{
			close();
		}


	public:
		// set of initial vector
		void setInitialVector(const BYTE* iv)
		{
			memcpy(ctx.initialVector, iv, ivSize);
		}

		// set of nonce initial vector
		void setNonceInitialVector(const BYTE* nonce)
		{
			memcpy(ctx.initialVector, nonce, nonceSize);
			encryptECB(ctx.initialVector, ivSize);
		}

		// set of nonce counter initial vector
		void setNonceCounterInitialVector(const BYTE* nonce)
		{
			// message = initial vector �� ���� ��
			// nonce = blockSize / 4
			BYTE message[(MAXBLOCKSIZE/4)];
			takeHash(message, ctx.initialVector, ivSize, (ctrSize / 4));
			memcpy(ctx.counterInitialVector, message, (ctrSize / 4));
			memcpy(ctx.counterInitialVector + (ctrSize / 4), nonce, nonceSize);

			// generate Counter
			updateCounter(0);
		}


		// get message authentication code
		const BYTE* getMac()
		{
			return ctx.mac;
		}

		// get nonce
		const BYTE* getNonce()
		{
			return ctx.nonce;
		}

		// get initial vector
		const BYTE* getInitialVector()
		{
			return ctx.initialVector;
		}

		// get counter initial vector
		const BYTE* getCounterInitialVector()
		{
			return ctx.counterInitialVector;
		}

		// get private key size
		const size_t getPrivateKeySize()
		{
			return pkSize;
		}

		// get initial vector size
		const size_t getInitialVectorSize()
		{
			return ivSize;
		}

		// get counter size
		const size_t getCounterInitialVectorSize()
		{
			return ctrSize;
		}

		//get blockSize
		const size_t getBlockSize()
		{
			return blockSize;
		}

		// get message authentication code size
		const size_t getMacSize()
		{ 
			return macSize; 
		}

		// get nonce size
		const size_t getNonceSize()
		{
			return nonceSize;
		}

		// get exception message
		const std::string getExceptionSymbol()
		{
			return exception;
		}


		// is counter
		bool isCounter()
		{
			return isGenerateCounterInitialVector;
		}

		// is initial vector
		bool isInitialVector()
		{
			return isGenerateInitialVector;
		}

		// is private Key
		bool isPrivateKey()
		{
			return isGeneratePrivateKey;
		}

		// is message authentication code
		bool isMAC()
		{
			return isGenerateMAC;
		}		

		// check of initialize
		bool initializeCheck(const int modType)
		{
			if (false == isPrivateKey()) {
				exception = ExceptionSymbol::GENERATE_KEY;
				return false;
			}

			if (modType == BlockCipherMode::CBC || modType == BlockCipherMode::CBC_CTS ||
				modType == BlockCipherMode::CFB ||	modType == BlockCipherMode::OFB) {
				if (false == isInitialVector()) {
					exception = ExceptionSymbol::GENERATE_IV;
					return false;
				}
			}

			if (modType == BlockCipherMode::COUNTER) {
				if (false == isCounter()) {
					exception = ExceptionSymbol::GENERATE_COUNTER;
					return false;
				}
			}

			return true;
		}

		// close
		void close()
		{
			memset(ctx.privateKey, NULL, sizeof(ctx.privateKey));
			memset(ctx.initialVector, NULL, sizeof(ctx.initialVector));
			memset(ctx.counterInitialVector, NULL, sizeof(ctx.counterInitialVector));
			memset(ctx.mac, NULL, sizeof(ctx.mac));
			memset(ctx.nonce, NULL, sizeof(ctx.nonce));

			memset(buf.blockBuffer[0], NULL, sizeof(buf.blockBuffer[0]));
			memset(buf.blockBuffer[1], NULL, sizeof(buf.blockBuffer[1]));
			memset(buf.blockBuffer[2], NULL, sizeof(buf.blockBuffer[2]));

			memset(buf.ctsBuffer[0], NULL, sizeof(buf.ctsBuffer[0]));
			memset(buf.ctsBuffer[1], NULL, sizeof(buf.ctsBuffer[1]));

			blockCipher.close();
			prng.close();
		}


	private:
		// initialize
		void initialize()
		{
			isGeneratePrivateKey = false;
			isGenerateInitialVector = false;
			isGenerateCounterInitialVector = false;
			isGenerateMAC = false;

			// Ű�� ���� ������ ����
			pkSize =  blockCipher.getPrivateKeyLength();
			ivSize = blockCipher.getBlockLength();
			ctrSize = blockCipher.getBlockLength();
			blockSize = blockCipher.getBlockLength();
			macSize = blockCipher.getPrivateKeyLength();
			nonceSize = (blockSize / 4);
		}

		// XOR
		void xor(BYTE* operand1, const BYTE* operand2, const size_t xorSize)
		{
			for (size_t i = 0; i < xorSize; i++) {
				operand1[i] ^= operand2[i];
			}
		}

		// calculate of block count
		const size_t calculateBlockCount(const size_t dataSize)
		{
			size_t blockCount = (dataSize / blockSize);
			const size_t mod = (dataSize % blockSize);

			// ������ ���� �ִ� ��� ������ �ϳ��� �ʿ�
			if (mod > 0)
				blockCount += 1;

			return blockCount;
		}


	/* ------------------------------------------- padding -----------------------------------------------
	*/
	private:
		// erase of padding data
		size_t fromPadding(BYTE* cipherData, const size_t dataSize, const int padType)
		{
			switch(padType) {
			case BlockCipherPadType::NONE:
				return dataSize;
			case BlockCipherPadType::PKCS7 :				
				return fromPKCS7(cipherData, dataSize);
			case BlockCipherPadType::AnsiX923 :				
				return fromAnsiX923(cipherData, dataSize);
			default:
				exception = ExceptionSymbol::PADDINGTYPE;
				return 0;
			}
		}

		// add of padding data
		size_t toPadding(BYTE* plainData, const size_t dataSize, const int padType)
		{
			switch(padType) {
			case BlockCipherPadType::NONE:
				return dataSize;
			case BlockCipherPadType::PKCS7 :				
				return toPKCS7(plainData, dataSize);
			case BlockCipherPadType::AnsiX923 :				
				return toAnsiX923(plainData, dataSize);
			default:
				exception = exception = ExceptionSymbol::PADDINGTYPE;
				return 0;
			}
		}

		// erase of AnsiX923 padding data
		size_t fromAnsiX923(BYTE* cipherData, const size_t dataSize)
		{
			const size_t paddingCount = cipherData[(dataSize - 1)];

			for(size_t i = 0; i < paddingCount; i++) {
				cipherData[((dataSize - 1) - i)] = NULL;
			}

			return (dataSize - paddingCount);
		}

		// add of AnsiX923 padding data
		size_t toAnsiX923(BYTE* plainData, const size_t dataSize)
		{
			const size_t paddingCount = (blockSize - (dataSize % blockSize));

			/* �������� ������ �������� �ʴ� ������ ����Ʈ�� ���� 
				�߰��� �е�����Ʈ�� ��ü���� �־��ش�.
			*/
			for(size_t i = 0; i < paddingCount; i++) {
				if (i == (paddingCount - 1)) {
					plainData[(dataSize + i)] = paddingCount;
				} else {
					plainData[(dataSize + i)] = 0;
				}
			}

			return (dataSize + paddingCount);
		}

		// erase of PKCS7 padding data
		size_t fromPKCS7(BYTE* cipherData, const size_t dataSize)
		{
			const size_t paddingCount = cipherData[(dataSize - 1)];

			for(size_t i = 0; i < paddingCount; i++) {
				cipherData[((dataSize - 1) - i)] = NULL;
			}

			return (dataSize - paddingCount);
		}

		// add of PKCS7 padding data
		size_t toPKCS7(BYTE* plainData, const size_t dataSize)
		{
			const size_t paddingCount = (blockSize - (dataSize % blockSize));

			/* �������� ������ �������� �ʴ� ������ ����Ʈ�� ���� 
				�߰��� �е�����Ʈ�� ��ü���� �־��ش�.
			*/
			for(size_t i = 0; i < paddingCount; i++) {
				plainData[(dataSize + i)]  = paddingCount;
			}

			return (dataSize + paddingCount);
		}


	/* ------------------------------------------- message authentication code  -----------------------------------------------
	*/
	public:
		// generate of message authentication code
		// BYTE* message = message
		bool generateMAC(const BYTE* data, const size_t dataSize, 
						const BYTE* message, const size_t messageSize)
		{
			// 0 = key
			// 1 = message
			// 2 = a
			// 3 = b
			// 4 = buffer
			BYTE macBuffer[5][MAXBYTE]; 
		
			// �ؽ������� ���̸� ����
			sha256(ctx.privateKey, pkSize, macBuffer[0]);
			sha256(message, messageSize, macBuffer[1]);

			// key�� message�� �ؽ����� ���� (a)
			takeHash(macBuffer[2], macBuffer[0], MAXBYTE, (MAXBYTE / 2));
			takeHash(macBuffer[2] + (MAXBYTE / 2), macBuffer[1], MAXBYTE, (MAXBYTE / 2));
			
			// b ���� ����
			sha256(macBuffer[2], MAXBYTE, macBuffer[3]);

			// calc hash
			BYTE temp[(MAXBYTE * 2)];
			xor(macBuffer[0], macBuffer[3], MAXBYTE);
			memcpy(temp, macBuffer[0], MAXBYTE);
			memcpy(temp + MAXBYTE, macBuffer[1], MAXBYTE);
			sha256(temp, (MAXBYTE * 2), macBuffer[4]);

			xor(macBuffer[0], macBuffer[2], MAXBYTE);
			memcpy(temp, macBuffer[0], MAXBYTE);
			memcpy(temp + MAXBYTE, macBuffer[4], MAXBYTE);
			sha256(temp, (MAXBYTE * 2), macBuffer[4]);

			takeHash(ctx.mac, macBuffer[4], MAXBYTE, macSize);

			isGenerateMAC = true;

			return true;
		}

		// authenticate of message authentication code
		bool authenticateMAC(const BYTE* mac, const BYTE* data, const size_t dataSize, 
							const BYTE* message, const size_t messageSize)
		{
			if (true == generateMAC(data, (dataSize - macSize), message, messageSize)) {
				if (memcmp(ctx.mac, mac, macSize) != 0) {
					exception = ExceptionSymbol::MACMESSAGE;
					return false;
				}
			} else {
				return false;
			}

			isGenerateMAC = true;

			return true;
		}


	/* ---------------------------------------------- key -------------------------------------------------
	*/
	private:
		// counter update
		void updateCounter(const int blockNumber)
		{
			// ������ ������ ī���ͷ� ���
			const size_t CounterSize = (ctrSize / 2);

			const size_t n = blockSize - 1;

			int count = blockNumber;
			for (size_t i = 0; i < CounterSize; i++) {
				size_t idx = (n - i);
				ctx.counterInitialVector[idx] = (count % 255);
				count /= 255;
			}

			encryptECB(ctx.counterInitialVector, ctrSize);	 // ECB ��ȣȭ
		}

		// generate counter initial vector
		void generateCounterInitialVector()
		{
			takeHash(ctx.counterInitialVector, ctx.initialVector, ivSize, (ctrSize / 2));
			isGenerateCounterInitialVector = true;	// Counter �� �������� �˸�
			updateCounter(0);
		}

		// generate random initial vector
		void generateRandomInitialVector()
		{
			prng.setKey(ctx.initialVector, ivSize);
			prng.PseudoRandomData(ctx.initialVector, ctx.privateKey, pkSize, ivSize);
		}

		// generate nonce initial vector
		void generateNonceInitialVector()
		{
			prng.setKey(ctx.initialVector, ivSize);
			prng.PseudoRandomData(ctx.nonce, ctx.privateKey, pkSize, nonceSize);
			
			memcpy(ctx.initialVector, ctx.nonce, nonceSize);

			encryptECB(ctx.initialVector, ivSize);	 // ECB ��ȣȭ
		}

		// generate nonce counter initial vector
		void generateNonceCounterInitialVector()
		{
			prng.setKey(ctx.initialVector, ivSize);
			prng.PseudoRandomData(ctx.nonce, ctx.privateKey, pkSize, nonceSize);

			BYTE message[(MAXBLOCKSIZE/4)];
			takeHash(message, ctx.initialVector, ivSize, (ctrSize/4));
			memcpy(ctx.counterInitialVector, message, (ctrSize/4));
			memcpy(ctx.counterInitialVector + (ctrSize/4), ctx.nonce, nonceSize);

			updateCounter(0);
		}


	public:
		// generate initial vector
		bool generateInitialVector(const BYTE* userIV, const size_t userIVSize, const int mode)
		{
			takeHash(ctx.initialVector, userIV, userIVSize, ivSize);

			switch(mode) {
			case InitialVectorMode::IV:
				break;
			case InitialVectorMode::COUNTER:
				generateCounterInitialVector();
				break;
			case InitialVectorMode::RANDOM:
				generateRandomInitialVector();
				break;
			case InitialVectorMode::NONCE:
				generateNonceInitialVector();
				break;
			case InitialVectorMode::NONCE_COUNTER:
				generateNonceCounterInitialVector();
				break;
			default:
				return false;
			}

			isGenerateInitialVector = true;	 // IV�� �������� �˸�

			return true;
		}

		// generate private key
		void generatePrivateKey(const BYTE* userKey, const size_t userKeySize)
		{
			takeHash(ctx.privateKey, userKey, userKeySize, pkSize);	
			blockCipher.privateKey(ctx.privateKey);	// Key ����
			isGeneratePrivateKey = true;	// Ű�� �������� �˸�
		}


	/* ----------------------------------------- take hash ------------------------------------------------
	*/
	private:
		// take hash
		// �ؽ��Ͽ� ���ϴ� ũ�⸸ŭ ��Ʈ���� ��´�.
		void takeHash(BYTE* digest, const BYTE* data, const size_t dataSize, const size_t hashSize)
		{
			BYTE hash[MAXBYTE];

			sha256(data, dataSize, hash);

			const size_t offset = (MAXBYTE / hashSize);

			for (size_t i = 0; i < hashSize; i++) {
				BYTE c = 0;
				for (size_t j = (i * offset); j < ((i * offset) + offset); j++) {
					c ^= hash[j];
				}
				hash[i] = c;
			}

			memcpy(digest, hash, hashSize);
		}


	/* ------------------------------------ block cipher operation --------------------------------------------
	*/
	public:
		// decrypt of CTR mode
		bool decryptCTR(BYTE* cipherData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::COUNTER))
				return false;		

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);

			size_t decryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				updateCounter(i);	// Count����
				blockCipher.encrypt(ctx.counterInitialVector);	// IV�� ��ȣȭ

				if (i == (BlockCount - 1))
					decryptSize = lastBlockDataSize;

				// ��ȣȭ�� CounterIV�� ���� xor
				xor(cipherData + (i * blockSize), ctx.counterInitialVector, decryptSize);
			}

			return true;
		}

		// encrypt of CTR  mode
		bool encryptCTR(BYTE* plainData, const size_t dataSize)
		{
			//generateCounterInitialVector();

			if (false == initializeCheck(BlockCipherMode::COUNTER))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);

			size_t encryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				updateCounter(i);	//Counter ������Ʈ				
				blockCipher.encrypt(ctx.counterInitialVector);	// Counter�� ��ȣȭ

				if (i == (BlockCount - 1))
					encryptSize = lastBlockDataSize;

				// ��ȣȭ�� Counter�� ���� xor
				xor(plainData + (i * blockSize), ctx.counterInitialVector, encryptSize);
			}

			return true;
		}

		// decrypt of OFB mode
		bool decryptOFB(BYTE* cipherData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::OFB))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);

			size_t decryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				blockCipher.encrypt(ctx.initialVector);	// IV�� ��ȣȭ
				
				if (i == (BlockCount - 1))
					decryptSize = lastBlockDataSize;

				// ��ȣȭ�� IV�� ���� xor
				xor(cipherData + (i * blockSize), ctx.initialVector, decryptSize);
			}

			return true;
		}

		// encrypt of OFB mode
		bool encryptOFB(BYTE* plainData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::OFB))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);

			size_t encryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				blockCipher.encrypt(ctx.initialVector);	// IV�� ��ȣȭ

				if (i == (BlockCount - 1))
					encryptSize = lastBlockDataSize;

				// ��ȣȭ�� IV�� ���� xor
				xor(plainData + (i * blockSize), ctx.initialVector, encryptSize);
			}

			return true;
		}

		// decrypt of CFB mode
		bool decryptCFB(BYTE* cipherData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::CFB))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);
		
			size_t decryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				memcpy(buf.blockBuffer[1], cipherData + (i * blockSize), decryptSize);

				if (i == 0) {
					// IV�� ��ȣȭ
					blockCipher.encrypt(ctx.initialVector);

					// ù��° ������ ����� �̴ϼ� ���͸� �̿��ؼ� xor
					xor(cipherData, ctx.initialVector, decryptSize);
				} else {
					if (i == (BlockCount - 1))
						decryptSize = lastBlockDataSize;

					// ���� ��ȣ���� ��ȣȭ
					blockCipher.encrypt(buf.blockBuffer[0]);
					xor(cipherData + (i * blockSize), buf.blockBuffer[0], decryptSize);
				}

				memcpy(buf.blockBuffer[0], buf.blockBuffer[1], decryptSize);
			}

			return true;
		}

		// encrypt of CFB mode
		bool encryptCFB(BYTE* plainData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::CFB))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);

			size_t encryptSize = blockSize;
			for (size_t i = 0; i < BlockCount; i++) {
				if (i == 0) {
					blockCipher.encrypt(ctx.initialVector);	// IV�� ��ȣȭ

					// ù��° ������ ����� �̴ϼ� ���͸� �̿��ؼ� xor
					xor(plainData, ctx.initialVector, encryptSize);
				} else { 
					if (i == (BlockCount - 1))
						encryptSize = lastBlockDataSize;

					// ���� ��ȣ���� ��ȣȭ
					blockCipher.encrypt(buf.blockBuffer[0]);
					xor(plainData + (i * blockSize), buf.blockBuffer[0], encryptSize);
				} 

				memcpy(buf.blockBuffer[0], plainData + (i * blockSize), encryptSize);
			}

			return true;
		}

		// decrypt of CBC-CTS mode
		bool decryptCBC_CTS(BYTE* cipherData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::CBC_CTS))
				return false;

			// CBC-CTS���� ������ 3�� �̻��̾�� �Ѵ�.
			if (dataSize <= (blockSize * 2)) {
				exception = ExceptionSymbol::CTSBLOCKCOUNT;
				return false;
			}

			// Block Count
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);
			const size_t stealingSize = (blockSize - lastBlockDataSize);

			// Decryption
			for (size_t i = 0; i < BlockCount; i++) {
				// ��ȣ���� ����
				memcpy(buf.blockBuffer[2], cipherData + (i * blockSize), blockSize);

				// ��ȣȭ
				if (i < (BlockCount - 1))
					blockCipher.decrypt(cipherData + (i * blockSize));

				/* ù��° �����̸� IV�� XOR �ϰ� �ƴϸ� ���� ��ȣ�� ���ϰ� XOR
				*/
				if (i == 0) {
					xor(cipherData, ctx.initialVector, blockSize);
				} else if ((i == (BlockCount - 2)) && (stealingSize > 0)) {
					// ������ ������ �ι�° ��ȣ�� ����
					xor(cipherData + (i * blockSize), buf.blockBuffer[1], blockSize);
					memcpy(buf.blockBuffer[0], buf.blockBuffer[1], blockSize);
				} else if ((i == (BlockCount - 1)) && (stealingSize > 0)) {
					// ������ ������ ù��° ��ȣ�� �� ������ ������ ��ȣ�� ��ȣȭ
					blockCipher.decrypt(buf.blockBuffer[1]);
					xor(buf.blockBuffer[1], buf.blockBuffer[2], blockSize);

					// ��ȣȭ�� ��ȣ�� cts_tail�� ����
					memcpy(buf.ctsBuffer[1], buf.blockBuffer[1], lastBlockDataSize);

					// cts_head�� ����
					memcpy(buf.ctsBuffer[0], buf.blockBuffer[2], lastBlockDataSize);
					memcpy(buf.ctsBuffer[0] + lastBlockDataSize, buf.blockBuffer[1] + lastBlockDataSize, stealingSize);
					blockCipher.decrypt(buf.ctsBuffer[0]);
					xor(buf.ctsBuffer[0], buf.blockBuffer[0], blockSize);
			
					memcpy(cipherData + ((i - 1) * blockSize), buf.ctsBuffer[0], blockSize);
					memcpy(cipherData + (i * blockSize), buf.ctsBuffer[1], lastBlockDataSize);
				} else {
					xor(cipherData + (i * blockSize), buf.blockBuffer[1], blockSize);
				}

				// ���� ��ȣ���� ����
				memcpy(buf.blockBuffer[1], buf.blockBuffer[2], blockSize);
			}

			return true;
		}

		// encrypt of CBC-CTS mode
		bool encryptCBC_CTS(BYTE* plainData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::CBC_CTS))
				return false;

			// CTS���� ������ 3�� �̻��̾�� �Ѵ�..
			if (dataSize <= (blockSize * 2)) {
				exception = ExceptionSymbol::CTSBLOCKCOUNT;
				return false;
			}

			// Block Count
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);
			const size_t stealingSize = (blockSize - lastBlockDataSize);

			for (size_t i = 0; i < BlockCount; i++) {
				if (i == 0) {
					// ù��° ������ ����� �̴ϼ� ���͸� �̿��ؼ� xor
					xor(plainData, ctx.initialVector, blockSize);
					blockCipher.encrypt(plainData + (i * blockSize));
				} else {
					if ((i == (BlockCount - 1)) && (stealingSize > 0)) {
						memcpy(buf.ctsBuffer[1], plainData + ((i - 1) * blockSize), lastBlockDataSize);
						memcpy(buf.ctsBuffer[0], plainData + ((i - 1) * blockSize), blockSize);

						xor(buf.ctsBuffer[0], plainData + (i * blockSize), blockSize);
						blockCipher.encrypt(buf.ctsBuffer[0]);

						memcpy(plainData + ((i - 1) * blockSize), buf.ctsBuffer[0], blockSize);
						memcpy(plainData + (i * blockSize), buf.ctsBuffer[1], lastBlockDataSize);
					} else {
						// ��ȣȭ�� ���� ������ ������ xor
						xor(plainData + (i * blockSize), plainData + ((i - 1) * blockSize), blockSize);
						blockCipher.encrypt(plainData + (i * blockSize));
					}
				}
			}

			return true;
		}

		// decrypt of CBC mode
		bool decryptCBC(BYTE* cipherData, const size_t dataSize, const int padType = BlockCipherPadType::NONE)
		{
			if (false == initializeCheck(BlockCipherMode::CBC))
				return false;

			// ������ ����
			const size_t BlockCount = calculateBlockCount(dataSize);

			for (size_t i = 0; i < BlockCount; i++) {
				memcpy(buf.blockBuffer[1], cipherData + (i * blockSize), blockSize);	// ��ȣ���� ����
				blockCipher.decrypt(cipherData + (i * blockSize));

				/* ù��° �����̸� IV�� XOR �ϰ� �ƴϸ� ���� ��ȣ�� ���ϰ� XOR
				*/
				if (i == 0) {
					xor(cipherData, ctx.initialVector, blockSize);
				} else {
					xor(cipherData + (i * blockSize), buf.blockBuffer[0], blockSize);
				}

				// ���� ��ȣ���� ����
				memcpy(buf.blockBuffer[0], buf.blockBuffer[1], blockSize);
			}

			// fromPadding
			fromPadding(cipherData, (BlockCount * blockSize), padType);

			return true;
		}

		// encrypt of CBC mode
		bool encryptCBC(BYTE* plainData, const size_t dataSize,  const int padType = BlockCipherPadType::NONE)
		{
			if (false == initializeCheck(BlockCipherMode::CBC))
				return false;	

			// Padding
			const size_t paddingDataLength = toPadding(plainData, dataSize, padType);

			// ������ ����
			size_t BlockCount = calculateBlockCount(paddingDataLength);

			for (size_t i = 0; i < BlockCount; i++) {
				if (i == 0) {
					// ù��° ������ ����� �̴ϼ� ���͸� �̿��ؼ� xor
					xor(plainData, ctx.initialVector, blockSize);
				} else {
					// ��ȣȭ�� ���� ������ ������ xor
					xor(plainData + (i * blockSize), plainData + ((i - 1) * blockSize), blockSize);
				}

				blockCipher.encrypt(plainData + (i * blockSize));
			}

			return true;
		}

		// decrypt of ECB-CTS mode
		bool decryptECB_CTS(BYTE* cipherData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::ECB_CTS))
				return false;

			// CTS���� ������ 2�� �̻��̾�� �Ѵ�
			if (dataSize <= blockSize) {
				exception = ExceptionSymbol::CTSBLOCKCOUNT;
				return false;
			}

			// Block Count
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);
			const size_t stealingSize = (blockSize - lastBlockDataSize);

			// Decryption
			for (size_t i = 0; i < BlockCount; i++) {
				if ((i == (BlockCount - 1)) && (BlockCount > 1) && (stealingSize > 0)) {
					/* Step 1. ������������ �����͸� �����ϰ�, ��ȣȭ�� ������ �ι�° ���Ͽ��� 
								��ƿũ�⸸ŭ �����͸� �ٿ��ְ� ������ ������ ����� �̸� ��ȣȭ �Ѵ�.
					*/
					memcpy(buf.ctsBuffer[0], cipherData + (i * blockSize), lastBlockDataSize);
					memcpy(buf.ctsBuffer[0] + lastBlockDataSize, cipherData + ((i * blockSize) - stealingSize), stealingSize);
					blockCipher.decrypt(buf.ctsBuffer[0]);
			
					/* Step 2. ������ �ι�° ������ Step 1�ּ� ������� ������ ���ϰ� �ٲپ� �ش�.
					*/
					memcpy(buf.ctsBuffer[1], cipherData + ((i - 1) * blockSize), lastBlockDataSize);				

					memcpy(cipherData + ((i - 1) * blockSize), buf.ctsBuffer[0], blockSize);
					memcpy(cipherData + (i * blockSize), buf.ctsBuffer[1], lastBlockDataSize);
				} else {
					blockCipher.decrypt(cipherData + (i * blockSize));
				}
			}

			return true;
		}

		// encrypt of ECB-CTS
		bool encryptECB_CTS(BYTE* plainData, const size_t dataSize)
		{
			if (false == initializeCheck(BlockCipherMode::ECB_CTS))
				return false;

			// CTS���� ������ 1�� �����̸� ���������� �������� �ʴ´�.
			if (dataSize <= blockSize) {
				exception = ExceptionSymbol::CTSBLOCKCOUNT;
				return false;
			}

			// Block Count
			const size_t BlockCount = calculateBlockCount(dataSize);
			const size_t lastBlockDataSize = (dataSize % blockSize);
			const size_t stealingSize = (blockSize - lastBlockDataSize);

			// Encryption
			for (size_t i = 0; i < BlockCount; i++) {
				if ((i == (BlockCount - 1)) && (BlockCount > 1) && (stealingSize > 0)) {
					/* Step 1. ������������ �����͸� �����ϰ�, ��ȣȭ�� ������ �ι�° ���Ͽ��� 
								��ƿũ�⸸ŭ �����͸� �ٿ��ְ� ������ ������ ����� �̸� ��ȣȭ �Ѵ�.
					*/
					memcpy(buf.ctsBuffer[0], plainData + (i * blockSize), lastBlockDataSize);
					memcpy(buf.ctsBuffer[0] + lastBlockDataSize, plainData + ((i * blockSize) - stealingSize), stealingSize);
					blockCipher.encrypt(buf.ctsBuffer[0]);
			
					/* Step 2. ������ �ι�° ������ ��ƿ�� ���ؼ� �ջ�Ǿ��� ������ �������� ��ȣȭ�� ���� �ʴ´�.
								Step 1�ּ� ������� ������ ���ϰ� �ٲپ� �ش�.
					*/
					memcpy(buf.ctsBuffer[1], plainData + ((i - 1) * blockSize), lastBlockDataSize);

					memcpy(plainData + ((i - 1) * blockSize), buf.ctsBuffer[0], blockSize);
					memcpy(plainData + (i * blockSize), buf.ctsBuffer[1], lastBlockDataSize);
				} else {		
					blockCipher.encrypt(plainData + (i * blockSize));
				}
			}

			return true;
		}

		// decrypt of ECB mode
		bool decryptECB(BYTE* cipherData, const size_t dataSize, const int padType = BlockCipherPadType::NONE)
		{	
			if (false == initializeCheck(BlockCipherMode::ECB))
				return false;	

   			// Block Count
			const size_t BlockCount = calculateBlockCount(dataSize);

			// Decryption
			for (size_t i = 0; i < BlockCount; i++) {
				blockCipher.decrypt(cipherData + (i * blockSize));
			}

			// fromPadding
			fromPadding(cipherData, (BlockCount * blockSize), padType);

			return true;
		}

		// encrypt of ECB mode
		bool encryptECB(BYTE* plainData, const size_t dataSize, const int padType = BlockCipherPadType::NONE)
		{
			if (false == initializeCheck(BlockCipherMode::ECB))
				return false;

			// Padding
			const size_t paddingDataLength = toPadding(plainData, dataSize, padType);

			// Block Count
			const size_t BlockCount = calculateBlockCount(paddingDataLength);

			// Encryption
			for (size_t i = 0; i < BlockCount; i++) {
				blockCipher.encrypt(plainData + (i * blockSize));
			}

			return true;
		}
	};
}

#endif