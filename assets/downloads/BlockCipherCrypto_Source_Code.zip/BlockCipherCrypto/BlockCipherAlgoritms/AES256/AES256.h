/*  
*   BYTE-oriented AES-256 implementation.
*   All lookup tables replaced with 'on the fly' calculations. 
*
*   Copyright (c) 2007-2009 Ilya O. Levin, http://www.literatecode.com
*   Other contributors: Hal Finney
*
*   Permission to use, copy, modify, and distribute this software for any
*   purpose with or without fee is hereby granted, provided that the above
*   copyright notice and this permission notice appear in all copies.
*
*   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
*   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
*   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
*   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
*   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
*   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
*   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/
#ifndef __AES256_H
#define __AES256_H

#include "./../../BlockCipherCryptoEnv.hpp"

namespace CipherAES
{
	typedef unsigned char BYTE;

	class AES256
	{
	public:
		AES256() {}
		virtual ~AES256() {}

	private:
		typedef struct {
			BYTE key[32]; 
			BYTE enckey[32]; 
			BYTE deckey[32];
		} aes256_context; 

		aes256_context m_Ctx;


	private:
		BYTE gf_alog(BYTE x);
		BYTE gf_log(BYTE x);
		BYTE gf_mulinv(BYTE x);
		BYTE rj_sbox(BYTE x);
		BYTE rj_sbox_inv(BYTE x);
		BYTE rj_xtime(BYTE x);

		void aes_subBytes(BYTE *buf);
		void aes_subBytes_inv(BYTE *buf);
		void aes_addRoundKey(BYTE *buf, BYTE *key);
		void aes_addRoundKey_cpy(BYTE *buf, BYTE *key, BYTE *cpk);
		void aes_shiftRows(BYTE *buf);
		void aes_shiftRows_inv(BYTE *buf);
		void aes_mixColumns(BYTE *buf);
		void aes_mixColumns_inv(BYTE *buf);
		void aes_expandEncKey(BYTE *k, BYTE *rc);
		void aes_expandDecKey(BYTE *k, BYTE *rc);


	public:
		void privateKey(BYTE * /* key */);
		void encrypt(BYTE * /* plaintext */);
		void decrypt(BYTE * /* cipertext */);

		int getPrivateKeyLength() {
			return 32;
		}

		int getBlockLength() {
			return 16;
		}

		int getAlgorithmType() {
			return BlockCipherCryptoEnv::BlockCipherAlgoritmType::AES256;
		}

		void setBitMode(int bit) {
			return;
		}

		void close();
	};
}

#endif
