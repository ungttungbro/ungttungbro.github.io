#include "ARIA.h"

using namespace CipherARIA;

/* ��ȣȭ �Լ�.
 * const BYTE *i: �Է�
 * int Nr: ���� ��
 * const BYTE *rk: ���� Ű��
 * BYTE *o: ���
 */
void ARIA::Crypt(const BYTE *i, int Nr, const BYTE *rk, BYTE *o) {
  register WORD t0, t1, t2, t3;
  
  WordLoad(WO(i,0), t0); WordLoad(WO(i,1), t1);
  WordLoad(WO(i,2), t2); WordLoad(WO(i,3), t3);
  
  if (Nr > 12) {KXL FO KXL FE}
  if (Nr > 14) {KXL FO KXL FE}
  KXL FO KXL FE KXL FO KXL FE KXL FO KXL FE 
  KXL FO KXL FE KXL FO KXL FE KXL FO KXL

  /* ���� ����� Ư���� */
#ifdef LITTLE_ENDIAN
  o[ 0] = (BYTE)(X1[BRF(t0,24)]   ) ^ rk[ 3];
  o[ 1] = (BYTE)(X2[BRF(t0,16)]>>8) ^ rk[ 2];
  o[ 2] = (BYTE)(S1[BRF(t0, 8)]   ) ^ rk[ 1];
  o[ 3] = (BYTE)(S2[BRF(t0, 0)]   ) ^ rk[ 0];
  o[ 4] = (BYTE)(X1[BRF(t1,24)]   ) ^ rk[ 7];
  o[ 5] = (BYTE)(X2[BRF(t1,16)]>>8) ^ rk[ 6];
  o[ 6] = (BYTE)(S1[BRF(t1, 8)]   ) ^ rk[ 5];
  o[ 7] = (BYTE)(S2[BRF(t1, 0)]   ) ^ rk[ 4];
  o[ 8] = (BYTE)(X1[BRF(t2,24)]   ) ^ rk[11];
  o[ 9] = (BYTE)(X2[BRF(t2,16)]>>8) ^ rk[10];
  o[10] = (BYTE)(S1[BRF(t2, 8)]   ) ^ rk[ 9];
  o[11] = (BYTE)(S2[BRF(t2, 0)]   ) ^ rk[ 8];
  o[12] = (BYTE)(X1[BRF(t3,24)]   ) ^ rk[15];
  o[13] = (BYTE)(X2[BRF(t3,16)]>>8) ^ rk[14];
  o[14] = (BYTE)(S1[BRF(t3, 8)]   ) ^ rk[13];
  o[15] = (BYTE)(S2[BRF(t3, 0)]   ) ^ rk[12];
#else
  o[ 0] = (BYTE)(X1[BRF(t0,24)]   );
  o[ 1] = (BYTE)(X2[BRF(t0,16)]>>8);
  o[ 2] = (BYTE)(S1[BRF(t0, 8)]   );
  o[ 3] = (BYTE)(S2[BRF(t0, 0)]   );
  o[ 4] = (BYTE)(X1[BRF(t1,24)]   );
  o[ 5] = (BYTE)(X2[BRF(t1,16)]>>8);
  o[ 6] = (BYTE)(S1[BRF(t1, 8)]   );
  o[ 7] = (BYTE)(S2[BRF(t1, 0)]   );
  o[ 8] = (BYTE)(X1[BRF(t2,24)]   );
  o[ 9] = (BYTE)(X2[BRF(t2,16)]>>8);
  o[10] = (BYTE)(S1[BRF(t2, 8)]   );
  o[11] = (BYTE)(S2[BRF(t2, 0)]   );
  o[12] = (BYTE)(X1[BRF(t3,24)]   );
  o[13] = (BYTE)(X2[BRF(t3,16)]>>8);
  o[14] = (BYTE)(S1[BRF(t3, 8)]   );
  o[15] = (BYTE)(S2[BRF(t3, 0)]   );
  WO(o,0)^=WO(rk,0); WO(o,1)^=WO(rk,1);
  WO(o,2)^=WO(rk,2); WO(o,3)^=WO(rk,3);
#endif
}

/* ��ȣȭ ���� Ű ����
 * const BYTE *mk: ������ Ű
 * BYTE *rk: ���� Ű
 * int keyBits: ������ Ű�� ����
 */
int ARIA::EncKeySetup(const BYTE *mk, BYTE *rk, int keyBits) {
  register WORD t0, t1, t2, t3;
  WORD w0[4], w1[4], w2[4], w3[4];
  int q, r;
  
  WordLoad(WO(mk,0), w0[0]); WordLoad(WO(mk,1), w0[1]);
  WordLoad(WO(mk,2), w0[2]); WordLoad(WO(mk,3), w0[3]);
  
  q = (keyBits - 128) / 64;
  t0=w0[0]^KRK[q][0]; t1=w0[1]^KRK[q][1];
  t2=w0[2]^KRK[q][2]; t3=w0[3]^KRK[q][3];
  FO;
  if (keyBits > 128) {
    WordLoad(WO(mk,4), w1[0]);
    WordLoad(WO(mk,5), w1[1]);
    if (keyBits > 192) {
      WordLoad(WO(mk,6), w1[2]);
      WordLoad(WO(mk,7), w1[3]);
    } else {
      w1[2]=w1[3]=0;
    }
  } else {
    w1[0]=w1[1]=w1[2]=w1[3]=0;
  }
  w1[0]^=t0; w1[1]^=t1; w1[2]^=t2; w1[3]^=t3;
  t0=w1[0];  t1=w1[1];  t2=w1[2];  t3=w1[3];
  
  q = (q==2)? 0 : (q+1);
  t0^=KRK[q][0]; t1^=KRK[q][1]; t2^=KRK[q][2]; t3^=KRK[q][3];
  FE;
  t0^=w0[0]; t1^=w0[1]; t2^=w0[2]; t3^=w0[3];
  w2[0]=t0; w2[1]=t1; w2[2]=t2; w2[3]=t3;
    
  q = (q==2)? 0 : (q+1);
  t0^=KRK[q][0]; t1^=KRK[q][1]; t2^=KRK[q][2]; t3^=KRK[q][3];
  FO;
  w3[0]=t0^w1[0]; w3[1]=t1^w1[1]; w3[2]=t2^w1[2]; w3[3]=t3^w1[3];
      
  GSRK(w0, w1, 19);
  GSRK(w1, w2, 19);
  GSRK(w2, w3, 19);
  GSRK(w3, w0, 19);
  GSRK(w0, w1, 31);
  GSRK(w1, w2, 31);
  GSRK(w2, w3, 31);
  GSRK(w3, w0, 31);
  GSRK(w0, w1, 67);
  GSRK(w1, w2, 67);
  GSRK(w2, w3, 67);
  GSRK(w3, w0, 67);
  GSRK(w0, w1, 97);
  if (keyBits > 128) {  
    GSRK(w1, w2, 97);
    GSRK(w2, w3, 97);
  }
  if (keyBits > 192) {
    GSRK(w3, w0,  97);
    GSRK(w0, w1, 109);
  }
  return (keyBits+256)/32; 
}

/* ��ȣȭ ���� Ű ����
 * const BYTE *mk: ������ Ű
 * BYTE *rk: ���� Ű
 * int keyBits: ������ Ű�� ����
 */
int ARIA::DecKeySetup(const BYTE *mk, BYTE *rk, int keyBits) {
  WORD *a, *z;
  int rValue;
#if defined(_MSC_VER)
  register WORD w;
#else
  register BYTE sum;
#endif
  register WORD t0, t1, t2, t3;
  WORD s0, s1, s2, s3;
  
  rValue=EncKeySetup(mk, rk, keyBits);
  a=(WORD *)(rk);  z=a+rValue*4;
  t0=a[0]; t1=a[1]; t2=a[2]; t3=a[3];
  a[0]=z[0]; a[1]=z[1]; a[2]=z[2]; a[3]=z[3];
  z[0]=t0; z[1]=t1; z[2]=t2; z[3]=t3;
  a+=4; z-=4;
  
  for (; a<z; a+=4, z-=4) {
    WORDM1(a[0],t0); WORDM1(a[1],t1); WORDM1(a[2],t2); WORDM1(a[3],t3);
    MM(t0,t1,t2,t3) P(t0,t1,t2,t3) MM(t0,t1,t2,t3)
      s0=t0; s1=t1; s2=t2; s3=t3;
    WORDM1(z[0],t0); WORDM1(z[1],t1); WORDM1(z[2],t2); WORDM1(z[3],t3);
    MM(t0,t1,t2,t3) P(t0,t1,t2,t3) MM(t0,t1,t2,t3)
      a[0]=t0; a[1]=t1; a[2]=t2; a[3]=t3;
    z[0]=s0; z[1]=s1; z[2]=s2; z[3]=s3;
  }
  WORDM1(a[0],t0); WORDM1(a[1],t1); WORDM1(a[2],t2); WORDM1(a[3],t3);
  MM(t0,t1,t2,t3) P(t0,t1,t2,t3) MM(t0,t1,t2,t3)
    z[0]=t0; z[1]=t1; z[2]=t2; z[3]=t3;
    
  return rValue;
}