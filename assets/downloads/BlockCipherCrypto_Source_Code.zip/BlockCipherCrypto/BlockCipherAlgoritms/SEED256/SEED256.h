/*******************************************************************************
*
* FILE:         SEED_256_KISA.h
*
* DESCRIPTION:  header file for SEED_256_KISA.c
*
*******************************************************************************/

#ifndef _SEED_256_KISA_H
#define _SEED_256_KISA_H

/********************** Include files ************************/

#include "./../../BlockCipherCryptoEnv.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

namespace CipherSEED
{
	/***************************** Endianness Define **************/
	// If endianness is not defined correctly, you must modify here.
	// SEED uses the Little endian as a defalut order

	#if __alpha__   ||      __alpha ||      __i386__        ||      i386    ||      _M_I86  ||      _M_IX86 ||      \
			__OS2__         ||      sun386  ||      __TURBOC__      ||      vax             ||      vms             ||      VMS             ||      __VMS
	#define SEED_LITTLE_ENDIAN
	#else
	#define SEED_BIG_ENDIAN
	#endif

	/**************** Function Prototype Declarations **************/

		/******************* Constant Definitions *********************/
		typedef unsigned char BYTE;

		#define NoRounds         24
		#define NoRoundKeys      (NoRounds*2)
		#define SeedBlockSize    16    /* in bytes */
		#define SeedBlockLen     128   /* in bits */


		/********************** Common Macros ************************/

		#if defined(_MSC_VER)
			#define ROTL(x, n)     (_lrotl((x), (n)))
			#define ROTR(x, n)     (_lrotr((x), (n)))
		#else
			#define ROTL(x, n)     (((x) << (n)) | ((x) >> (32-(n))))
			#define ROTR(x, n)     (((x) >> (n)) | ((x) << (32-(n))))
		#endif


		/********************* Type Definitions **********************/
		#ifndef TYPE_DEFINITION
			#define TYPE_DEFINITION
			#if defined(__alpha)
				typedef unsigned int        DWORD;
				typedef unsigned short      WORD;
			#else
				typedef unsigned long int   DWORD;
				typedef unsigned short int  WORD;
			#endif
		#endif

		/******************* Encryption/Decryption *******************/

		#define GetB0(A)  ( (BYTE)((A)    ) )
		#define GetB1(A)  ( (BYTE)((A)>> 8) )
		#define GetB2(A)  ( (BYTE)((A)>>16) )
		#define GetB3(A)  ( (BYTE)((A)>>24) )

		#define SeedRound(L0, L1, R0, R1, K) {             \
			T0 = R0 ^ (K)[0];                              \
			T1 = R1 ^ (K)[1];                              \
			T1 ^= T0;                                      \
			T1 = SS0[GetB0(T1)] ^ SS1[GetB1(T1)] ^         \
					SS2[GetB2(T1)] ^ SS3[GetB3(T1)];          \
			T0 += T1;                                      \
			T0 = SS0[GetB0(T0)] ^ SS1[GetB1(T0)] ^         \
					SS2[GetB2(T0)] ^ SS3[GetB3(T0)];          \
			T1 += T0;                                      \
			T1 = SS0[GetB0(T1)] ^ SS1[GetB1(T1)] ^         \
					SS2[GetB2(T1)] ^ SS3[GetB3(T1)];          \
			T0 += T1;                                      \
			L0 ^= T0; L1 ^= T1;                            \
		}


		#define EndianChange(dwS)                       \
			( (ROTL((dwS),  8) & (DWORD)0x00ff00ff) |   \
				(ROTL((dwS), 24) & (DWORD)0xff00ff00) )

	class SEED256
	{
	public:
		SEED256() {}
		virtual ~SEED256() {}


	private:
		DWORD m_RoundKey[NoRoundKeys];


	public:
		void encrypt(		/* encryption function */
				BYTE *pbData			// [in,out]	data to be encrypted
				/*KEY *pRoundKey*/		// [in]			round keys for encryption
				);
		void decrypt(		/* decryption function */
				BYTE *pbData			// [in,out]	data to be decrypted
				/*KEY *pRoundKey*/		// [in]			round keys for decryption
				);
		void privateKey(		/* key scheduling function */
				/*KEY *pRoundKey,*/ 	// [out]		round keys for encryption or decryption
				BYTE *pbUserKey			// [in]			secret user key 
				);

		int getPrivateKeyLength() {
			return 32;
		}

		int getBlockLength() {
			return SeedBlockSize;
		}

		int getAlgorithmType() {
			return BlockCipherCryptoEnv::BlockCipherAlgoritmType::SEED256;
		}

		void setBitMode(int bit) {
			return;
		}

		void close() { 
			memset(m_RoundKey, 0x00, sizeof(m_RoundKey)); 
		}
	};
}

/*************************** END OF FILE **************************************/
#endif