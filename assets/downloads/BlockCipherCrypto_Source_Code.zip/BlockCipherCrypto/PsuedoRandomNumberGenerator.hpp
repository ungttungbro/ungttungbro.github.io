/******************************************************************************************************
		�ǻ糭��������(Psuedorandom Number Generator)
	
	    ������ : �念�� [ jywan@naver.com ]
		����ó : blog.naver.com/jywan
		������ : 2014�� 9�� 23��
********************************************************************************************************/

#include "./HashAlgorithms/SHA2/SHA2.h"
#include "./BlockCipherAlgoritms/AES256/AES256.h"

#include <iostream>
#include <ctime>

namespace PRNG
{
	const size_t MAXBYTE = 32;
	const size_t KEYSIZE = 32;
	const size_t RANDOMBYTESIZE = (16384 / MAXBYTE);
	const size_t BLOCKSIZE = 16;
	const size_t COUNTERSIZE = 8;

	class PsuedoRandomNumberGenerator
	{
		typedef struct {
			unsigned char key[KEYSIZE];
			unsigned char counter[COUNTERSIZE];
		} PRNGState;

	private:
		PRNGState state;
		unsigned char randomBytes[MAXBYTE][RANDOMBYTESIZE];
		CipherAES::AES256 aes;
		size_t count;

	public:
		PsuedoRandomNumberGenerator()
		{
			initializeGenerator();
		}

		virtual ~PsuedoRandomNumberGenerator() {}


	private:
		// �ʱ�ȭ
		void initializeGenerator()
		{
			memset(state.key, NULL, KEYSIZE);
			memset(state.counter, NULL, COUNTERSIZE);
			count = 0;

			for (size_t i = 0; i < MAXBYTE; i++) 
				memset(randomBytes[i], NULL, RANDOMBYTESIZE);
		}

		// ����Ʈ�� �ʱ�ȭ
		void initializeRandomBytes()
		{
			for (size_t i = 0; i < MAXBYTE; i++) 
				memset(randomBytes[i], NULL, RANDOMBYTESIZE);			
		}

		// �ؽ����̸� ������ ���� 32 -> 16
		void takeHashBlock(unsigned char* output, const unsigned char* seed, const size_t seedSize)
		{
			unsigned char S[MAXBYTE];

			sha256(seed , seedSize, S);

			const size_t offset = (MAXBYTE / BLOCKSIZE);

			for (size_t i = 0; i < BLOCKSIZE; i++) {
				unsigned char c = 0;
				for (size_t j = (i * offset); j < ((i * offset) + offset); j++) {
					c ^= S[j];
				}
				output[i] = c;
			}
		}

		// counter
		void updateCounter(const size_t count)
		{
			size_t cnt = count;
			for (size_t i = 0; i < COUNTERSIZE; i++) {
				size_t idx = ((COUNTERSIZE - 1) - i);
				state.counter[idx] = (cnt % 10);
				cnt /= 10;
			}
		}

		// �õ� �����
		void Reseed(const unsigned char* seed)
		{
			unsigned char S[(KEYSIZE + MAXBYTE + COUNTERSIZE)];

			memcpy(S, state.key, KEYSIZE);
			memcpy(S, state.counter, COUNTERSIZE);
			memcpy(S, seed, MAXBYTE);

			sha256(S, (KEYSIZE + MAXBYTE, COUNTERSIZE), state.key);

			count += 1;
			updateCounter(count);
		}

		// ���� �����
		bool generateBlocks(const unsigned char* seed, const size_t seedSize)
		{
			if (1 > seedSize)
				return false;
			
			unsigned char S[BLOCKSIZE];

			takeHashBlock(S, seed, seedSize);
	
			for (size_t i = 0; i < MAXBYTE; i++) {
				for (size_t j = 0; j < MAXBYTE; j++) {
					Reseed(S);
					aes.privateKey(state.key);
					aes.encrypt(S);
					memcpy(randomBytes[i] + (j * BLOCKSIZE), S, BLOCKSIZE);
				}
			}

			return true;
		}

	public:
		// Ű�� ����
		void setKey(const unsigned char* key, const size_t keySize)
		{
			unsigned char K[KEYSIZE];

			sha256(key, keySize, K);
			memcpy(state.key, K, KEYSIZE);
		}

		// �ǻ糭��������
		// �õ�, �õ�ũ��, ��¹���Ʈ���� �Է������� ������ ��¹���Ʈ ��ŭ ������ ���
		bool PseudoRandomData(unsigned char* output, const unsigned char* seed, const size_t seedSize, const size_t outRandomByteSize)
		{
			if (1024 < outRandomByteSize)
				return false;

			generateBlocks(seed, seedSize);

			srand((unsigned int)time(NULL));
			for (size_t i = 0; i < outRandomByteSize; i++) {
				size_t randomIdx = rand() % (MAXBYTE + 1);
				size_t randomValue = rand() % (RANDOMBYTESIZE + 1);
				output[i] = randomBytes[randomIdx][randomValue];
			}

			//initializeRandomBytes();	 // �ǻ糭�� Ǯ �ʱ�ȭ

			return true;
		}

		// ���� (PseudoRandomData ���� �ʿ信 ���� initializeRandomBytes��� ���)
		void close()
		{
			initializeGenerator();
			//initializeRandomBytes();
		}
	};
}