#include <stdio.h>
#include <stdlib.h>

int main()
{
	char world[32][16] = { {"Brazil"}, {"Germany"}, {"England"}, {"France"}, {"Italy"}, {"Portugal"},
				{"Argentina"}, {"USA"}, {"South Korea"}, {"Japan"}, {"Iran"}, {"Urguay"},
				{"Netheland"}, {"Paraguay"}, {"Mexico"}, {"Spain"}, {"Swith"}, {"Sweden"},
				{"Saudi Arabia"}, {"Bolibia"}, {"Greece"}, {"Iland"}, {"Poland"}, {"Russia"},
				{"Finland"}, {"Greenland"}, {"Belgium"}, {"Togo"}, {"Moroco"}, {"South Africa"},
				{"Canada"}, {"Austrailia"} };

	int num[32] = { 0, 1, 2, 3, 4, 5, 6, 7, 
						8, 9, 10, 11, 12, 13, 14, 15,
						16, 17, 18, 19, 20, 21, 22, 23,
						24, 25, 26, 27, 28, 29, 30, 31 };

	int i = 0;
	int random;
	int flag = 1;

	while(1) {
		random = rand() % 32;

		if (num[random] != 99) {
			printf("%-16s", world[random]);
			num[random] = 99;
			i++;

			if (i % 8 == 0) {
				printf("\n");
			}

			if (i >= 32) {
				break;
			}
		}
	}

	printf("\n");
	system("pause");

	return 0;
}